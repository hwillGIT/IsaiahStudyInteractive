export interface Verse {
  number: number;
  text: string;
  color: string;
  colorName: string;
  group: string;
  structuralPartners?: number[];
}

export const verseColorMap = {
  1: { color: '#DC2626', colorName: 'Judgment/Hierarchy Removal', group: 'When God Removes Our Supports' },
  2: { color: '#DC2626', colorName: 'Judgment/Hierarchy Removal', group: 'When God Removes Our Supports' },
  3: { color: '#DC2626', colorName: 'Judgment/Hierarchy Removal', group: 'When God Removes Our Supports' },
  4: { color: '#CA8A04', colorName: 'Social Inversion and Failed Leadership', group: 'Unexpected Leadership Changes' },
  5: { color: '#CA8A04', colorName: 'Social Inversion and Failed Leadership', group: 'Unexpected Leadership Changes' },
  6: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  7: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  8: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  9: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  10: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  11: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  12: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart' },
  13: { color: '#0D9488', colorName: 'Theological Rationale and Guilt', group: 'Society Falls Apart - The Turning Point' },
  14: { color: '#059669', colorName: 'Divine Lawsuit and Indictment', group: 'God Speaks to Leaders' },
  15: { color: '#059669', colorName: 'Divine Lawsuit and Indictment', group: 'God Speaks to Leaders' },
  16: { color: '#9333EA', colorName: 'Women\'s Haughtiness and Punishment', group: 'God Judges Pride' },
  17: { color: '#9333EA', colorName: 'Women\'s Haughtiness and Punishment', group: 'God Judges Pride' },
  18: { color: '#9333EA', colorName: 'Finery Inventory and Reversal', group: 'God Judges Pride' },
  19: { color: '#9333EA', colorName: 'Finery Inventory and Reversal', group: 'God Judges Pride' },
  20: { color: '#4F46E5', colorName: 'Finery Inventory and Reversal', group: 'Complete Reversal' },
  21: { color: '#4F46E5', colorName: 'Finery Inventory and Reversal', group: 'Complete Reversal' },
  22: { color: '#4F46E5', colorName: 'Finery Inventory and Reversal', group: 'Complete Reversal' },
  23: { color: '#4F46E5', colorName: 'Finery Inventory and Reversal', group: 'Complete Reversal' },
  24: { color: '#4F46E5', colorName: 'Finery Inventory and Reversal', group: 'Complete Reversal' },
  25: { color: '#6B7280', colorName: 'Lament and Desolation', group: 'The Final Outcome' },
  26: { color: '#6B7280', colorName: 'Lament and Desolation', group: 'The Final Outcome' },
};

export const verses: Verse[] = [
  {
    number: 1,
    text: "For behold, the Lord God of hosts is taking away from Jerusalem and from Judah support and supply, all support of bread, and all support of water;",
    ...verseColorMap[1]
  },
  {
    number: 2,
    text: "the mighty man and the soldier, the judge and the prophet, the diviner and the elder,",
    ...verseColorMap[2]
  },
  {
    number: 3,
    text: "the captain of fifty and the man of rank, the counselor and the skillful magician and the expert in charms.",
    ...verseColorMap[3]
  },
  {
    number: 4,
    text: "And I will make boys their princes, and infants shall rule over them.",
    ...verseColorMap[4]
  },
  {
    number: 5,
    text: "And the people will oppress one another, every one his fellow and every one his neighbor; the youth will be insolent to the elder, and the despised to the honorable.",
    ...verseColorMap[5]
  },
  {
    number: 6,
    text: "For a man will take hold of his brother in the house of his father, saying: \"You have a cloak; you shall be our leader, and this heap of ruins shall be under your rule\";",
    ...verseColorMap[6]
  },
  {
    number: 7,
    text: "in that day he will speak out, saying: \"I will not be a healer; in my house there is neither bread nor cloak; you shall not make me leader of the people.\"",
    ...verseColorMap[7]
  },
  {
    number: 8,
    text: "For Jerusalem has stumbled, and Judah has fallen, because their speech and their deeds are against the Lord, defying his glorious presence.",
    ...verseColorMap[8]
  },
  {
    number: 9,
    text: "For the look on their faces bears witness against them; they proclaim their sin like Sodom; they do not hide it. Woe to them! For they have brought evil on themselves.",
    ...verseColorMap[9]
  },
  {
    number: 10,
    text: "Tell the righteous that it shall be well with them, for they shall eat the fruit of their deeds.",
    ...verseColorMap[10]
  },
  {
    number: 11,
    text: "Woe to the wicked! It shall be ill with him, for what his hands have dealt out shall be done to him.",
    ...verseColorMap[11]
  },
  {
    number: 12,
    text: "My people—infants are their oppressors, and women rule over them. O my people, your guides mislead you and they have swallowed up the course of your paths.",
    ...verseColorMap[12]
  },
  {
    number: 13,
    text: "The Lord has taken his place to contend; he stands to judge peoples.",
    ...verseColorMap[13]
  },
  {
    number: 14,
    text: "The Lord will enter into judgment with the elders and princes of his people: \"It is you who have devoured the vineyard, the spoil of the poor is in your houses.",
    ...verseColorMap[14]
  },
  {
    number: 15,
    text: "What do you mean by crushing my people, by grinding the face of the poor?\" declares the Lord God of hosts.",
    ...verseColorMap[15]
  },
  {
    number: 16,
    text: "The Lord said: \"Because the daughters of Zion are haughty and walk with outstretched necks, glancing wantonly with their eyes, mincing along as they go, tinkling with their feet,",
    ...verseColorMap[16]
  },
  {
    number: 17,
    text: "therefore the Lord will strike with a scab the heads of the daughters of Zion, and the Lord will lay bare their secret parts.\"",
    ...verseColorMap[17]
  },
  {
    number: 18,
    text: "In that day the Lord will take away the finery of the anklets, the headbands, and the crescents;",
    ...verseColorMap[18]
  },
  {
    number: 19,
    text: "the pendants, the bracelets, and the scarves;",
    ...verseColorMap[19]
  },
  {
    number: 20,
    text: "the headdresses, the armlets, the sashes, the perfume boxes, and the amulets;",
    ...verseColorMap[20]
  },
  {
    number: 21,
    text: "the signet rings and nose rings;",
    ...verseColorMap[21]
  },
  {
    number: 22,
    text: "the festal robes, the mantles, the cloaks, and the handbags;",
    ...verseColorMap[22]
  },
  {
    number: 23,
    text: "the mirrors, the linen garments, the turbans, and the veils.",
    ...verseColorMap[23]
  },
  {
    number: 24,
    text: "Instead of perfume there will be rottenness; and instead of a belt, a rope; and instead of well-set hair, baldness; and instead of a rich robe, a skirt of sackcloth; and branding instead of beauty.",
    ...verseColorMap[24]
  },
  {
    number: 25,
    text: "Your men shall fall by the sword and your mighty men in battle.",
    ...verseColorMap[25]
  },
  {
    number: 26,
    text: "And her gates shall lament and mourn; empty, she shall sit on the ground.",
    ...verseColorMap[26]
  }
];

// Verse connections for pattern recognition
export const structuralRelationships = {
  1: [24], // Support removal mirrors complete reversal
  2: [23], // Leadership list mirrors personal items removal
  3: [22], // Extended list mirrors clothing removal
  4: [16], // Children rule mirrors pride judgment
  5: [17], // Social chaos mirrors physical judgment
  6: [20], // Failed leadership mirrors status symbol removal
  7: [21], // Leadership refusal mirrors ring removal
  8: [18], // Spiritual cause mirrors physical effect
  9: [19], // Sin exposure mirrors jewelry removal
  10: [25], // Righteous blessing mirrors battle loss
  11: [26], // Wicked judgment mirrors city mourning
  12: [14], // Leadership failure mirrors divine indictment
  13: [15], // Courtroom opening matches charges (center)
};

// Viewing mode content - reader focused
export const viewingModes = {
  structure: {
    title: "Seeing Connections",
    description: "How verses relate and mirror each other to teach us"
  },
  life: {
    title: "Life Application", 
    description: "How these verses speak to our daily walk with God"
  },
  compare: {
    title: "Contrasts That Teach",
    description: "Comparing verses to see what God wants us to learn"
  },
  literary: {
    title: "Hidden Messages",
    description: "Spiritual insights and themes woven through the text"
  }
};

// Devotional analysis focused on reader application
export const verseAnalysis = {
  1: {
    structure: "God begins by removing everything people rely on - food, water, and leadership",
    life: "God removes our supports to reveal where our true trust lies",
    compare: "This systematic removal prepares us for the complete transformation later",
    literary: "Notice how 'support and supply' bookends what follows - God is removing foundations"
  },
  2: {
    structure: "Every kind of authority figure is listed - military, spiritual, and civic leaders",
    life: "No human authority is permanent; all ultimately serve at God's discretion",
    compare: "This list shows how comprehensive God's removal will be",
    literary: "Each pair (mighty/soldier, judge/prophet) represents different aspects of human structure"
  },
  3: {
    structure: "The list expands to include specialized roles and even magical arts",
    life: "Even worldly wisdom and power cannot protect us when God moves",
    compare: "Like the final clothing list later, this shows exhaustive completeness",
    literary: "The progression from military to magical shows the full spectrum of human help"
  },
  4: {
    structure: "Dramatic reversal - children become rulers over adults",
    life: "God can humble the proud and lift up the humble in unexpected ways",
    compare: "This pairs with the pride judgment against women - both show God's upside-down kingdom",
    literary: "The irony of infants ruling shows how completely human structures collapse"
  },
  5: {
    structure: "Social order completely breaks down - young against old, lowly against honored",
    life: "When God removes restraint, society devolves into chaos",
    compare: "This social inversion mirrors the physical inversion that follows",
    literary: "The threefold progression (oppress, insult, despise) shows worsening conditions"
  },
  6: {
    structure: "Desperate search for leadership even in complete ruins",
    life: "People will grasp for any authority when God's covering is lifted",
    compare: "Pairs with the headdress removal - people try to grab status symbols",
    literary: "'Heap of ruins' as a kingdom to rule shows the desperation"
  },
  7: {
    structure: "Even when offered leadership, capable people refuse - no resources to lead",
    life: "True leaders serve because they can contribute, not just for power",
    compare: "Leadership refusal pairs with ring removal - both show loss of status",
    literary: "Repetition of 'neither bread nor cloak' emphasizes complete lack"
  },
  8: {
    structure: "The theological explanation - everything falls because people defied God's presence",
    life: "All judgment flows from our rebellion against who God is",
    compare: "This spiritual cause leads directly to physical effects in the next verses",
    literary: "Stumble/fall imagery shows how sin creates instability"
  },
  9: {
    structure: "Public accountability - faces reveal hidden sin",
    life: "Sin cannot stay secret; it always manifests somehow",
    compare: "Exposure of guilt leads to exposure of status symbols",
    literary: "Sodom reference shows the depth of corruption"
  },
  10: {
    structure: "Clear promise for the righteous - blessing follows obedience",
    life: "God's people will experience His goodness despite surrounding chaos",
    compare: "Positive hope contrasts with the coming judgments",
    literary: "Fruit metaphor shows lasting consequences of our choices"
  },
  11: {
    structure: "Equally clear warning for the wicked - judgment returns to the sender",
    life: "We cannot escape the consequences of our actions",
    compare: "Sharp contrast with verse 10 - two distinct paths",
    literary: "Reciprocity principle - what we plant, we harvest"
  },
  12: {
    structure: "Return to leadership inversion - still no stable guidance",
    life: "Even God's people will face periods without proper spiritual leadership",
    compare: "Repeats and intensifies verse 4's theme of failed guidance",
    literary: "'O my people' shows God's tender heartbreak over His people"
  },
  13: {
    structure: "Divine courtroom opens - God takes His judicial seat",
    life: "God will hold every person and nation accountable",
    compare: "Central turning point where judgment transitions from warning to action",
    literary: "Legal language shows this is a formal divine proceeding"
  },
  14: {
    structure: "God's specific charges against leaders - they've exploited His people",
    life: "Those in authority answer to God for how they treat others",
    compare: "Direct challenge to those who think they're immune from accountability",
    literary: "Vineyard imagery reminds us this is God's people they're mistreating"
  },
  15: {
    structure: "God demands explanation - how can they justify their actions?",
    life: "We must be able to explain our choices to God",
    compare: "These courtroom charges pair with the opening of court in verse 13",
    literary: "Rhetorical question - no defense is possible"
  },
  16: {
    structure: "God addresses spiritual pride through physical pride",
    life: "Our attitude shows up in how we carry ourselves",
    compare: "Pairs with children ruling - both show pride before fall",
    literary: "Detailed sensory description shows how obvious their pride was"
  },
  17: {
    structure: "God humbles through physical affliction - opposite of their prideful display",
    life: "God often uses physical circumstances to address spiritual pride",
    compare: "Physical judgment mirrors the social chaos of verse 5",
    literary: "Disease and exposure imagery shows complete reversal"
  },
  18: {
    structure: "Catalog of status symbols begins - systematic stripping of pride markers",
    life: "Worldly status cannot protect us from God's judgment",
    compare: "This begins the physical effects of the spiritual cause in verse 8",
    literary: "The detailed catalog shows nothing will be missed"
  },
  19: {
    structure: "Continuation of status symbol removal",
    life: "All outward markers of success will prove worthless",
    compare: "Jewelry removal mirrors the guilt exposure in verse 9",
    literary: "Progressive inventory shows thoroughness"
  },
  20: {
    structure: "Expansion to include even protective and religious items",
    life: "Even things we trust for protection cannot save us",
    compare: "Headdress removal parallels the failed leadership attempts",
    literary: "Including amulets shows false security being removed"
  },
  21: {
    structure: "Rings symbolize both authority and identity - both lost",
    life: "Our earthly identity and status are temporary",
    compare: "Ring removal pairs with leadership refusal - loss of both claimed and offered status",
    literary: "Signet rings represent legal authority; nose rings represent personal beauty"
  },
  22: {
    structure: "Garments represent social position and role",
    life: "Our clothing and accessories reflect how we present ourselves to the world",
    compare: "This clothing list mirrors the leadership list in verse 3",
    literary: "From festive to daily wear shows all social contexts affected"
  },
  23: {
    structure: "Personal items of care and modesty are taken",
    life: "Even our private securities will be exposed",
    compare: "Personal care items mirror the personal leadership roles in verse 2",
    literary: "Mirrors and veils become ironic - privacy becomes public exposure"
  },
  24: {
    structure: "Complete transformation - everything becomes its opposite",
    life: "God's judgment creates the opposite of what we expect",
    compare: "The culmination of all removal themes from the beginning",
    literary: "The 'instead of' formula shows systematic inversion"
  },
  25: {
    structure: "Military consequences of spiritual rebellion",
    life: "When we reject God's ways, violence often follows",
    compare: "War casualties contrast with the righteous blessing promised",
    literary: "Direct statement without mitigation shows finality"
  },
  26: {
    structure: "Even creation mourns the desolation caused by sin",
    life: "The whole world suffers when people reject God",
    compare: "City grief mirrors the judgment against the wicked",
    literary: "Personification shows the depth of the destruction"
  }
};