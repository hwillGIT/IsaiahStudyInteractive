import React from 'react';
import { VerseGrid } from './components/VerseGrid';
import './App.css';

function App() {
  return (
    <div className="App">
      <VerseGrid />
    </div>
  );
}

export default App;