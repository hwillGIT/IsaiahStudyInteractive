import React, { useState } from 'react';
import { Verse, verses, structuralRelationships, viewingModes } from '../data/verses';
import { VerseBlock } from './VerseBlock';
import { DetailedAnalysis } from './DetailedAnalysis';

export const VerseGrid: React.FC = () => {
  const [selectedVerse, setSelectedVerse] = useState<Verse | null>(null);
  const [viewingMode, setViewingMode] = useState<keyof typeof viewingModes>('structure');
  const [hoveredVerse, setHoveredVerse] = useState<number | null>(null);

  const handleVerseClick = (verse: Verse) => {
    setSelectedVerse(verse);
  };

  const handleVerseHover = (verseNumber: number | null) => {
    setHoveredVerse(verseNumber);
  };

  const getHighlightedVerses = () => {
    if (!hoveredVerse) return [];
    
    const partners = structuralRelationships[hoveredVerse as keyof typeof structuralRelationships] || [];
    return [hoveredVerse, ...partners];
  };

  const highlightedVerses = getHighlightedVerses();

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Isaiah Chapter 3: Interactive Study
          </h1>
          <p className="text-lg text-gray-600 mb-4">
            Seeing God's Patterns and Teaching Us How to Live
          </p>
          <p className="text-sm text-gray-500">
            Explore how verses connect and teach us about God's character. 
            Hover to see connections, click for deeper reflection.
          </p>
        </div>

        {/* Viewing Mode Selector */}
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-4">
            {Object.entries(viewingModes).map(([key, mode]) => (
              <button
                key={key}
                onClick={() => setViewingMode(key as keyof typeof viewingModes)}
                className={`
                  px-4 py-2 rounded-lg font-medium transition-all duration-200
                  ${viewingMode === key 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }
                `}
              >
                <div className="text-sm font-semibold">{mode.title}</div>
                <div className="text-xs opacity-80">{mode.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Main Grid */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="grid grid-cols-8 gap-3 justify-items-center">
            {verses.map((verse) => (
              <div key={verse.number} className="relative">
                <VerseBlock
                  verse={verse}
                  viewingMode={viewingMode}
                  onClick={handleVerseClick}
                  isHighlighted={highlightedVerses.includes(verse.number)}
                  structuralPartners={structuralRelationships[verse.number as keyof typeof structuralRelationships] || []}
                />
                
                {/* Verse label below block */}
                <div className="text-xs text-center mt-2 text-gray-600 max-w-16">
                  <div className="font-medium">Verse {verse.number}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pattern Overview */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            How Verses Connect to Teach Us
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">What You'll Discover</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#DC2626' }}></div>
                  <span>Judgment/Hierarchy Removal (Verses 1-3)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#CA8A04' }}></div>
                  <span>Social Inversion and Failed Leadership (Verses 4-7)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#0D9488' }}></div>
                  <span>Theological Rationale and Guilt (Verses 8-9)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#059669' }}></div>
                  <span>Divine Lawsuit and Indictment (Verses 12-15)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#9333EA' }}></div>
                  <span>Women's Haughtiness and Punishment (Verses 16-17)</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#4F46E5' }}></div>
                  <span>Finery Inventory and Reversal (Verses 18-24)</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Key Themes</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#6B7280' }}></div>
                  <span>Verses 25-26: The Final Outcome</span>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <div className="text-xs font-medium text-blue-800 mb-1">
                    What This Teaches Us
                  </div>
                  <ul className="text-xs text-blue-700 space-y-1">
                    <li>• Verse 13: The center where God takes His throne</li>
                    <li>• Verse 24: Everything becomes its opposite</li>
                    <li>• Early verses echo in the conclusion</li>
                    <li>• God promises hope for the righteous (verse 10)</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Key Transformation Points */}
        <div className="bg-white rounded-lg p-4 shadow-md mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Key transformation points</h3>
          <div className="flex items-start gap-3">
            <div className="w-3 h-3 bg-yellow-400 rounded-full mt-1 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">Yellow dots mark moments where everything changes—from leadership collapse to social inversion, from theological rationale to public guilt exposure, from haughtiness to humiliation.</p>
          </div>
        </div>

        {/* How to Use */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            How to Use This Study
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Getting Started</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• <strong>Hover:</strong> See verse text and how it connects to others</li>
                <li>• <strong>Click:</strong> Open detailed reflection in your chosen focus area</li>
                <li>• <strong>Gold Ring:</strong> Shows which verses teach similar lessons</li>
                <li>• <strong>Mode Switch:</strong> Change what you want to focus on learning</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 mb-2">What to Look For</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• <strong>Yellow Dot:</strong> Marks verse 13 where God judges (center point)</li>
                <li>• <strong>Connected Verses:</strong> Show how God teaches the same lesson twice</li>
                <li>• <strong>Color Groups:</strong> Help you see patterns in God's teaching</li>
                <li>• <strong>All Verses Visible:</strong> See the complete picture at once</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Detailed Analysis Modal */}
        {selectedVerse && (
          <DetailedAnalysis
            verse={selectedVerse}
            viewingMode={viewingMode}
            onClose={() => setSelectedVerse(null)}
          />
        )}
      </div>
    </div>
  );
};