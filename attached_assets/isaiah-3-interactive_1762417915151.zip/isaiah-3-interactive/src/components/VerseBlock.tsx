import React, { useState } from 'react';
import { Verse, structuralRelationships, verseAnalysis, viewingModes } from '../data/verses';

interface VerseBlockProps {
  verse: Verse;
  viewingMode: keyof typeof viewingModes;
  onClick: (verse: Verse) => void;
  isHighlighted?: boolean;
  structuralPartners: number[];
}

export const VerseBlock: React.FC<VerseBlockProps> = ({
  verse,
  viewingMode,
  onClick,
  isHighlighted = false,
  structuralPartners
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  const handleMouseEnter = (event: React.MouseEvent) => {
    setShowTooltip(true);
    setTooltipPosition({ x: event.clientX, y: event.clientY });
  };

  const handleMouseMove = (event: React.MouseEvent) => {
    setTooltipPosition({ x: event.clientX, y: event.clientY });
  };

  const handleMouseLeave = () => {
    setShowTooltip(false);
  };

  const handleClick = () => {
    onClick(verse);
  };

  const getTooltipContent = () => {
    const analysis = verseAnalysis[verse.number as keyof typeof verseAnalysis];
    const partners = structuralRelationships[verse.number as keyof typeof structuralRelationships] || [];
    
    switch (viewingMode) {
      case 'structure':
        return {
          title: `Verse ${verse.number} - Seeing Connections`,
          content: analysis?.structure || 'No connection analysis available',
          partners: partners.length > 0 ? `Also teaches this: Verses ${partners.join(', ')}` : null
        };
      case 'life':
        return {
          title: `Verse ${verse.number} - Life Application`,
          content: analysis?.life || 'No life application available',
          partners: null
        };
      case 'compare':
        return {
          title: `Verse ${verse.number} - What This Teaches Us`,
          content: analysis?.compare || 'No comparative lesson available',
          partners: partners.length > 0 ? `God teaches this again in: Verses ${partners.join(', ')}` : null
        };
      case 'literary':
        return {
          title: `Verse ${verse.number} - Hidden Messages`,
          content: analysis?.literary || 'No hidden messages available',
          partners: null
        };
      default:
        return {
          title: `Verse ${verse.number}`,
          content: verse.text,
          partners: null
        };
    }
  };

  const tooltip = getTooltipContent();

  return (
    <>
      <div
        className={`
          relative w-16 h-16 rounded-lg border-2 cursor-pointer transition-all duration-200 
          flex items-center justify-center text-white font-bold text-sm
          hover:scale-105 hover:shadow-lg hover:z-10
          ${isHighlighted ? 'ring-4 ring-yellow-400 ring-opacity-60' : ''}
        `}
        style={{ backgroundColor: verse.color }}
        onMouseEnter={handleMouseEnter}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
      >
        <span className="text-center leading-tight">{verse.number}</span>
        
        {/* Subtle highlight for structural partners */}
        {structuralPartners.includes(verse.number) && (
          <div className="absolute inset-0 rounded-lg border-2 border-yellow-300 border-opacity-60 pointer-events-none" />
        )}
        
        {/* Special indicator for verse 13 (central hinge) */}
        {verse.number === 13 && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full border border-white" />
        )}
      </div>

      {/* Tooltip */}
      {showTooltip && (
        <div
          className="fixed z-50 bg-white border border-gray-300 rounded-lg shadow-xl p-4 max-w-sm"
          style={{
            left: Math.min(tooltipPosition.x + 10, window.innerWidth - 350),
            top: Math.max(tooltipPosition.y - 10, 10),
            pointerEvents: 'none'
          }}
        >
          <div className="text-sm font-semibold text-gray-800 mb-2">
            {tooltip.title}
          </div>
          
          {viewingMode === 'structure' && verse.text && (
            <div className="text-xs text-gray-600 mb-2 border-b pb-2">
              <strong>What it says:</strong> {verse.text}
            </div>
          )}
          
          <div className="text-sm text-gray-700 mb-2">
            {tooltip.content}
          </div>
          
          {tooltip.partners && (
            <div className="text-xs text-blue-600 font-medium">
              {tooltip.partners}
            </div>
          )}
          
          <div className="text-xs text-gray-500 mt-2 pt-2 border-t">
            Click for deeper reflection
          </div>
        </div>
      )}
    </>
  );
};