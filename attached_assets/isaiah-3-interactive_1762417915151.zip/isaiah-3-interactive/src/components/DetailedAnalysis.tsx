import React from 'react';
import { Verse, verseAnalysis, viewingModes, structuralRelationships } from '../data/verses';

interface DetailedAnalysisProps {
  verse: Verse;
  viewingMode: keyof typeof viewingModes;
  onClose: () => void;
}

export const DetailedAnalysis: React.FC<DetailedAnalysisProps> = ({
  verse,
  viewingMode,
  onClose
}) => {
  const analysis = verseAnalysis[verse.number as keyof typeof verseAnalysis];
  const partners = structuralRelationships[verse.number as keyof typeof structuralRelationships] || [];

  const getAnalysisContent = () => {
    if (!analysis) {
      return {
        title: `Verse ${verse.number}`,
        content: 'No reflection available for this verse yet.',
        partners: null
      };
    }

    switch (viewingMode) {
      case 'structure':
        return {
          title: `Verse ${verse.number} - Seeing Connections`,
          content: analysis.structure,
          partners: partners.length > 0 ? partners : null
        };
      case 'life':
        return {
          title: `Verse ${verse.number} - How This Helps My Life`,
          content: analysis.life,
          partners: null
        };
      case 'compare':
        return {
          title: `Verse ${verse.number} - What This Teaches Us`,
          content: analysis.compare,
          partners: partners.length > 0 ? partners : null
        };
      case 'literary':
        return {
          title: `Verse ${verse.number} - Hidden Messages`,
          content: analysis.literary,
          partners: null
        };
      default:
        return {
          title: `Verse ${verse.number}`,
          content: verse.text,
          partners: null
        };
    }
  };

  const content = getAnalysisContent();

  // Get reflection questions based on verse number and theme
  const getReflectionQuestions = () => {
    const questions = {
      1: [
        "What are you tempted to trust in besides God?",
        "How does this verse challenge your sense of security?",
        "What would happen if God removed your main support systems?"
      ],
      2: [
        "Which authority figures in your life do you trust most?",
        "How might God use unexpected people to lead?",
        "What does it mean that all authority comes from God?"
      ],
      4: [
        "How do you respond when God's ways seem upside-down?",
        "When has God humbled someone proud in your experience?",
        "What does this teach us about God's kingdom?"
      ],
      8: [
        "How do you 'defy God's glorious presence' in your daily life?",
        "What makes you stumble spiritually?",
        "When has your speech or actions been 'against the Lord'?"
      ],
      10: [
        "What are you trusting God for right now?",
        "How do you see God's blessing in your obedience?",
        "What 'fruit' are you producing through your choices?"
      ],
      13: [
        "How does this verse comfort you about God's justice?",
        "What areas of your life need God's judgment?",
        "How can you prepare for God's coming justice?"
      ],
      16: [
        "What prideful attitudes does God want to humble in you?",
        "How does your physical posture reflect your spiritual condition?",
        "What areas of pride do you need to repent of?"
      ],
      24: [
        "How has God transformed your expectations?",
        "What in your life needs to become 'its opposite'?",
        "How do you see God's grace in this complete reversal?"
      ]
    };

    return questions[verse.number as keyof typeof questions] || [
      "What is God teaching you through this verse?",
      "How does this connect to your own spiritual journey?",
      "What do you need to confess or change?"
    ];
  };

  const reflectionQuestions = getReflectionQuestions();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        {/* Header */}
        <div 
          className="p-6 text-white rounded-t-xl"
          style={{ backgroundColor: verse.color }}
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">{content.title}</h2>
              <p className="text-white/90 text-sm mt-1">
                {verse.group}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-2xl font-bold w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/20"
            >
              ×
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* ESV Text */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-2">What the Bible Says</h3>
            <div className="bg-gray-50 p-4 rounded-lg border-l-4" style={{ borderLeftColor: verse.color }}>
              <p className="text-gray-700 leading-relaxed italic">
                "{verse.text}"
              </p>
            </div>
          </div>

          {/* Analysis Content */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-3">
              {viewingModes[viewingMode].title}
            </h3>
            <div className="prose prose-sm max-w-none">
              <p className="text-gray-700 leading-relaxed">
                {content.content}
              </p>
            </div>
          </div>

          {/* Connected Verses */}
          {content.partners && content.partners.length > 0 && (
            <div className="mb-6">
              <h3 className="font-semibold text-gray-800 mb-3">How This Connects</h3>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800 mb-2">
                  God teaches this same lesson in another verse:
                </p>
                <div className="flex flex-wrap gap-2">
                  {content.partners.map((partnerVerse) => (
                    <button
                      key={partnerVerse}
                      onClick={() => {
                        // You could add logic here to highlight the partner verse
                        // For now, just close this modal
                        onClose();
                      }}
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer transition-colors"
                    >
                      Verse {partnerVerse}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-blue-600 mt-2">
                  God often teaches the same truth in different ways to help us understand better.
                </p>
              </div>
            </div>
          )}

          {/* Reflection Questions */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-3">Questions for Your Heart</h3>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-green-800 mb-3">
                Take time to honestly consider these questions:
              </p>
              <ul className="text-sm text-green-700 space-y-2">
                {reflectionQuestions.map((question, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">•</span>
                    <span>{question}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* What This Means for You */}
          <div className="border-t pt-4">
            <h3 className="font-semibold text-gray-800 mb-2">What This Means for Your Life</h3>
            <div className="text-sm text-gray-600 space-y-2">
              <p>
                <strong>Your Position:</strong> You're studying verse {verse.number} of 26 in Isaiah Chapter 3
              </p>
              <p>
                <strong>Theme:</strong> {verse.group}
              </p>
              {verse.number === 13 && (
                <p className="text-yellow-700 font-medium">
                  ⭐ This is the center of the chapter - where God takes His throne to judge
                </p>
              )}
              {verse.number === 24 && (
                <p className="text-purple-700 font-medium">
                  🔄 This verse shows how God turns everything upside-down for those who trust Him
                </p>
              )}
              {verse.number === 25 || verse.number === 26 ? (
                <p className="text-gray-700 font-medium">
                  📜 These final verses show us the ultimate outcome - both judgment and hope
                </p>
              ) : null}
              <div className="mt-3 p-3 bg-amber-50 rounded-lg">
                <p className="text-xs text-amber-800 font-medium">
                  💭 Remember: Every verse points us back to God's character and His desire for our transformation.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t px-6 py-4 bg-gray-50 rounded-b-xl">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Focus Area: <span className="font-medium">{viewingModes[viewingMode].title}</span>
            </p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Continue Studying
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};