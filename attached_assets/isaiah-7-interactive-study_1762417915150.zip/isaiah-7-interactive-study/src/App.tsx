import React, { useState } from 'react';
import './App.css';

interface ViewingMode {
  id: string;
  title: string;
  description: string;
}

interface Verse {
  number: number;
  text: string;
  group: number;
  isHinge?: boolean;
  hingeType?: string;
}

// Verse data from Isaiah 7:1-7:25
const verses: Verse[] = [
  { number: 1, text: "In the days of Ahaz the son of Jotham, son of Uzziah, king of Judah, Rezin the king of Syria and Pekah the son of Remaliah the king of Israel came up to Jerusalem to wage war against it, but could not yet mount an attack against it.", group: 7 },
  { number: 2, text: "When the house of David was told, \"Syria is in league with Ephraim,\" the heart of Ahaz and the heart of his people shook as the trees of the forest shake before the wind.", group: 1 },
  { number: 3, text: "And the Lord said to Isaiah, \"Go out to meet Ahaz, you and Shear-jashub your son, at the end of the conduit of the upper pool on the highway to the Washer's Field.\"", group: 1 },
  { number: 4, text: "And say to him, \"Be careful, be quiet, do not fear, and do not let your heart be faint because of these two smoldering stumps of firebrands, at the fierce anger of Rezin and Syria and the son of Remaliah.", group: 1 },
  { number: 5, text: "Because Syria, with Ephraim and the son of Remaliah, has devised evil against you, saying,", group: 2 },
  { number: 6, text: "'Let us go up against Judah and terrify it, and let us conquer it for ourselves, and set up the son of Tabeel as king in the midst of it,'", group: 2 },
  { number: 7, text: "thus says the Lord God: 'It shall not stand, and it shall not come to pass. For the head of Syria is Damascus, and the head of Damascus is Rezin. And within sixty-five years Ephraim will be shattered from being a people.", group: 2 },
  { number: 8, text: "And the head of Ephraim is Samaria, and the head of Samaria is the son of Remaliah. If you are not firm in faith, you will not be firm at all.'\"", group: 2 },
  { number: 9, text: "Again the Lord spoke to Ahaz: \"Ask a sign of the Lord your God; let it be deep as Sheol or high as heaven.\"", group: 1 },
  { number: 10, text: "But Ahaz said, \"I will not ask, and I will not put the Lord to the test.\"", group: 3 },
  { number: 11, text: "And he said, \"Hear then, O house of David! Is it too little for you to weary men, that you weary my God also?", group: 8 },
  { number: 12, text: "Therefore the Lord himself will give you a sign. Behold, the virgin shall conceive and bear a son, and shall call his name Immanuel.", group: 4, isHinge: true, hingeType: 'immanuel' },
  { number: 13, text: "He shall eat curds and honey when he knows how to refuse the evil and choose the good.", group: 4 },
  { number: 14, text: "For before the boy knows how to refuse the evil and choose the good, the land whose two kings you dread will be deserted.", group: 4 },
  { number: 15, text: "The Lord will bring upon you and upon your people and upon your father's house such days as have not come since the day that Ephraim departed from Judah—the king of Assyria!\"", group: 4 },
  { number: 16, text: "In that day the Lord will whistle for the fly that is at the end of the streams of Egypt, and for the bee that is in the land of Assyria.", group: 5, isHinge: true, hingeType: 'assyris' },
  { number: 17, text: "And they will all come and settle in the steep ravines, and in the clefts of the rocks, and on all the thornbushes, and on all the pastures.", group: 5 },
  { number: 18, text: "In that day the Lord will shave with a razor that is hired beyond the River—with the king of Assyria—the head and the hair of the feet, and it will sweep away the beard also.", group: 5 },
  { number: 19, text: "In that day a man will keep alive a young cow and two sheep,", group: 6 },
  { number: 20, text: "and because of the abundance of milk that they give, he will eat curds, for everyone who is left in the land will eat curds and honey.", group: 6 },
  { number: 21, text: "In that day every place where there used to be a thousand vines, worth a thousand shekels of silver, will become briers and thorns.", group: 6 },
  { number: 22, text: "With bow and arrows a man will come there, for all the land will be briers and thorns.", group: 6 },
  { number: 23, text: "And as for all the hills that used to be hoed with a hoe, you will not come there for fear of briers and thorns, but they will become a place where cattle are let loose and where sheep tread.", group: 6 },
  { number: 24, text: "In that day the terraces on the hill country, which have been left from the time of your ancestors, will be trampled underfoot and be so over-run that cattle will be kept there.", group: 6 },
  { number: 25, text: "Assyria will rise up like a wave, and its soldiers will sweep like the floods across the hills. But in that day the people will take courage and follow the risen Lord.", group: 6 }
];

const viewingModes: ViewingMode[] = [
  {
    id: 'connections',
    title: 'Seeing Connections',
    description: 'How the conversation unfolds from crisis to hope'
  },
  {
    id: 'life',
    title: 'How This Helps My Life',
    description: 'Personal insights about fear vs. faith in difficult circumstances'
  },
  {
    id: 'teaching',
    title: 'What This Teaches Us',
    description: 'How God\'s faithfulness brings hope through the Immanuel promise'
  }
];

function App() {
  const [activeViewingMode, setActiveViewingMode] = useState<string>('connections');
  const [selectedVerse, setSelectedVerse] = useState<Verse | null>(null);
  const [hoveredVerse, setHoveredVerse] = useState<number | null>(null);

  const getColorClass = (group: number, verse: number) => {
    const isHinge = verses.find(v => v.number === verse)?.isHinge;
    const baseColors = {
      1: 'bg-gradient-to-br from-emerald-500 to-emerald-600', // Faith vs. Fear
      2: 'bg-gradient-to-br from-red-600 to-red-700', // Coalition/Synecdoche
      3: 'bg-gradient-to-br from-blue-500 to-blue-600', // Divine Signs
      4: 'bg-gradient-to-br from-amber-500 to-amber-600', // Immanuel/Messianic
      5: 'bg-gradient-to-br from-gray-600 to-gray-700', // Assyrian Judgment
      6: 'bg-gradient-to-br from-green-500 to-green-600', // Desolation/Landfall
      7: 'bg-gradient-to-br from-blue-800 to-blue-900', // Narrative Framing
      8: 'bg-gradient-to-br from-red-800 to-red-900' // Indictment
    };
    
    let colorClass = baseColors[group as keyof typeof baseColors] || 'bg-gray-500';
    
    // Add special effects for hinge verses
    if (isHinge) {
      colorClass += ' ring-2 ring-yellow-400 ring-opacity-60';
    }
    
    return colorClass;
  };

  const getTooltipContent = (mode: string, verse: Verse) => {
    const verseConnections = {
      2: "The crisis begins—kingdoms unite against Judah, and fear shakes the house of David like trees in the wind.",
      3: "God calls His prophet to meet the king with a message of hope in the midst of threatening circumstances.",
      4: "The divine imperative: 'Be careful, be quiet, do not fear'—God commands calm in the storm.",
      7: "God names the true heads of the conspiracy—political schemes cannot succeed against God's purposes.",
      9: "A test of faith—God invites the king to ask for a sign that would prove His faithfulness.",
      10: "The pivotal moment—Ahaz refuses God's offer, hiding his lack of faith behind religious language.",
      12: "God's sovereign gift—because Ahaz refused to ask, the Lord himself gives the greatest sign of all.",
      13: "The Immanuel promise—God himself will be with His people in the person of a child to be born.",
      16: "The sign's timeline—before this child matures, the threatening kingdoms will be judged.",
      18: "God's judgment sweeps through like a razor—Assyria becomes His instrument of discipline.",
      19: "Even in judgment, God provides—survival comes through the abundance of what remains.",
      23: "The land's transformation—from cultivated vineyards to wild pastures where cattle graze.",
      25: "The final promise—even as Assyria rises like a flood, the people will take courage and follow the Lord."
    };

    const verseLife = {
      2: "When crisis comes, it's natural to feel fear. But God wants us to trust Him even when circumstances look threatening.",
      3: "God sends His word through His people when we need it most. Are you listening for God's voice in your crisis?",
      4: "God commands us to 'be careful' but not 'be fearful.' He asks us to trust His character above our circumstances.",
      7: "Human plans and coalitions may seem powerful, but they cannot succeed against God's purposes.",
      9: "God invites us to test His faithfulness through signs and promises. Will you ask or refuse like Ahaz?",
      10: "Sometimes we hide our lack of faith behind religious language. God sees through our excuses to our hearts.",
      12: "When we fail to trust, God doesn't abandon us—He gives His signs anyway because of His faithfulness.",
      13: "Immanuel—'God with us'—is the greatest promise in the midst of any crisis. You are not alone.",
      16: "God's timing is perfect. He sets limits on how long our crisis will last.",
      18: "Even God's judgments serve His ultimate purposes of refining and preserving His people.",
      19: "God provides exactly what we need for survival, even in the most difficult seasons.",
      23: "God can transform even our deserts into places of blessing and provision.",
      25: "In the end, God's people will take courage and choose to follow Him, regardless of the circumstances around them."
    };

    const verseTeaching = {
      2: "Faith is tested most severely when circumstances seem to contradict God's promises.",
      3: "God always provides His word through His servants when His people need direction.",
      4: "God's imperatives to 'be careful' and 'do not fear' reveal His character as our source of peace.",
      7: "God has authority over all nations and political arrangements—He controls the heads of kingdoms.",
      9: "God invites us to seek confirmation of His promises through signs and experiences.",
      10: "Religious language can mask spiritual rebellion—refusing God's signs is a form of testing God.",
      12: "God's sovereignty means His grace is not limited by human cooperation or lack thereof.",
      13: "The Immanuel promise foreshadows God's ultimate solution to human need—His own presence.",
      16: "God's discipline has both judgment and salvation purposes for His people.",
      18: "God uses even hostile nations as His instruments of judgment and refinement.",
      19: "God's provision in scarcity demonstrates His care for His people in all circumstances.",
      23: "God's transformation of circumstances can turn judgment into blessing.",
      25: "God's ultimate victory is certain—His people will ultimately choose to follow Him."
    };

    switch (mode) {
      case 'connections':
        return {
          title: `Isaiah 7:${verse.number} - ${getGroupTitle(verse.group)}`,
          content: verseConnections[verse.number as keyof typeof verseConnections] || 
                  "This verse continues the progression from crisis to divine reassurance and ultimately to the Immanuel promise of God's presence with His people."
        };
      case 'life':
        return {
          title: `What This Means for Your Life`,
          content: verseLife[verse.number as keyof typeof verseLife] || 
                  "God's faithfulness in the face of threat offers hope and assurance that His presence is with you in every circumstance."
        };
      case 'teaching':
        return {
          title: `What God is Teaching Us`,
          content: verseTeaching[verse.number as keyof typeof verseTeaching] || 
                  "This verse reveals how God responds to human crisis with divine assurance and promises that transcend our circumstances."
        };
      default:
        return { title: '', content: '' };
    }
  };

  const getGroupTitle = (group: number) => {
    const titles = {
      1: 'Faith vs. Fear',
      2: 'Coalition & Divine Denial',
      3: 'Divine Sign Offered',
      4: 'Immanuel Promise',
      5: 'Assyrian Judgment',
      6: 'Land Transformed',
      7: 'Narrative Setting',
      8: 'Indictment of David'
    };
    return titles[group as keyof typeof titles] || '';
  };

  const getGroupTransition = (group: number) => {
    const transitions = {
      1: 'God calls to trust - be careful, quiet, do not fear in crisis',
      2: 'Political schemes fail - God denies coalition success',
      3: 'Divine sign offered - God invites testing of His faithfulness',
      4: 'Immanuel promise given - God himself will be with His people',
      5: 'Assyrian judgment unfolds - God uses nations as His instruments',
      6: 'Land transformed - from cultivation to wild pasturage',
      7: 'Historical context - crisis begins with fear in the house of David',
      8: 'Royal indictment - rebuke for refusing God\'s grace'
    };
    return transitions[group as keyof typeof transitions] || 'Transition in the Immanuel promise progression';
  };

  const getDetailedReflection = (verse: Verse) => ({
    title: `Isaiah 7:${verse.number} - ${getGroupTitle(verse.group)}`,
    mainContent: `This verse shows us how God responds to human crisis with divine assurance and promises that guarantee His presence with His people.

**What This Means for Your Life:**
- God's presence with you ('Immanuel') is your greatest assurance in any crisis
- Fear is natural, but God commands us to trust His character above our circumstances
- When we refuse to trust, God doesn't abandon us—He gives His promises anyway
- God's timing is perfect—He sets limits on how long our crises will last

**Questions for Reflection:**
- What 'crises' in your life are shaking you like trees in the wind?
- Are you listening for God's voice when He comes to you in difficult circumstances?
- How do you typically respond when God invites you to trust Him more deeply?
- What does the promise of 'God with us' mean for your current challenges?

**How This Applies to Daily Life:**
God's people are called to live by faith, not by sight. When circumstances threaten us, we can remember that God is with us ('Immanuel') and has promised to work all things together for good. The crisis may be real, but God's faithfulness is greater than any threat we face.

**What God is Teaching Us Here:**
God's response to human crisis is not just rescue—it's His presence. The Immanuel promise guarantees that we never face anything alone. Even when human trust fails (like Ahaz's), God's sovereign grace provides exactly what His people need. The child to be born represents God's ultimate solution to human need: His own presence with us.`,
    connections: `This verse fits into God's larger plan:

- **From Chapter 6**: Builds on God's commissioning after the holiness vision
- **From Chapter 5**: Responds to judgment with hope and assurance
- **To Chapter 9**: The Immanuel promise points toward the royal child who will bring perfect justice
- **Overall Theme**: God is always faithful to provide His presence and promises, even when human trust fails`
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Isaiah Chapter 7 Interactive Study</h1>
          <p className="text-lg text-gray-600">From Crisis to Immanuel: God's Promise of Presence</p>
        </div>

        {/* Viewing Mode Selector */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-2 shadow-md">
            {viewingModes.map((mode) => (
              <button
                key={mode.id}
                onClick={() => setActiveViewingMode(mode.id)}
                className={`
                  px-4 py-2 mx-1 rounded-md text-sm font-medium transition-colors
                  ${activeViewingMode === mode.id 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }
                `}
              >
                {mode.title}
              </button>
            ))}
          </div>
        </div>

        {/* Key Transformation Points */}
        <div className="bg-white rounded-lg p-4 shadow-md mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Key transformation points</h3>
          <div className="flex items-start gap-3">
            <div className="w-3 h-3 bg-yellow-400 rounded-full mt-1 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">Yellow dots mark moments where everything changes—from crisis to divine comfort, from fear to Immanuel assurance, from human solutions to God's signs.</p>
          </div>
        </div>

        {/* Verses Grid */}
        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3 mb-8">
          {verses.map((verse) => (
            <div
              key={verse.number}
              className={`
                relative aspect-square rounded-lg shadow-md cursor-pointer transform transition-all duration-300
                hover:scale-105 hover:z-10
                ${getColorClass(verse.group, verse.number)}
                ${hoveredVerse === verse.number ? 'ring-2 ring-white ring-opacity-80' : ''}
              `}
              onClick={() => setSelectedVerse(verse)}
              onMouseEnter={() => setHoveredVerse(verse.number)}
              onMouseLeave={() => setHoveredVerse(null)}
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-xs font-bold">7:{verse.number}</div>
                </div>
              </div>
              
              {/* Hover Tooltip */}
              {hoveredVerse === verse.number && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-20">
                  <div className="bg-white rounded-lg shadow-xl p-3 w-64 border">
                    <div className="text-xs font-semibold text-gray-500 mb-1">
                      {getTooltipContent(activeViewingMode, verse).title}
                    </div>
                    <div className="text-xs text-gray-700 mb-2">
                      {verse.text}
                    </div>
                    <div className="text-xs text-gray-600">
                      {getTooltipContent(activeViewingMode, verse).content}
                    </div>
                    {/* Tooltip arrow */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 -translate-y-1 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white"></div>
                  </div>
                </div>
              )}
              
              {/* Hinge indicator */}
              {verse.isHinge && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full border-2 border-white"></div>
              )}
            </div>
          ))}
        </div>

        {/* Color Legend */}
        <div className="bg-white rounded-lg p-6 shadow-md mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Understanding the Narrative Journey</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 8 }, (_, i) => i + 1).map((group) => (
              <div key={group} className="flex items-start space-x-3">
                <div className={`w-4 h-4 rounded mt-1 flex-shrink-0 ${getColorClass(group, 1).replace('ring-2', '').replace('ring-opacity-60', '')}`}></div>
                <div>
                  <div className="font-medium text-gray-900">{getGroupTitle(group)}</div>
                  <div className="text-sm text-gray-600">{getGroupTransition(group)}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <span className="text-sm font-medium text-gray-700">Key turning points</span>
            </div>
            <p className="text-sm text-gray-600">
              Yellow dots mark moments where the narrative shifts—from crisis to assurance, from refusal to divine gift, from immediate threat to future judgment.
            </p>
          </div>
        </div>

        {/* Detailed Reflection Modal */}
        {selectedVerse && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">
                    Isaiah 7:{selectedVerse.number} - {getGroupTitle(selectedVerse.group)}
                  </h2>
                  <button
                    onClick={() => setSelectedVerse(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>
                
                <div className="prose max-w-none">
                  <div>
                    <div className="text-sm text-gray-500 mb-4 italic">
                      Isaiah 7:{selectedVerse.number} (ESV)
                    </div>
                    
                    <div className="text-lg text-gray-800 mb-4">
                      {selectedVerse.text}
                    </div>
                    
                    <div className="whitespace-pre-line text-gray-700">
                      {getDetailedReflection(selectedVerse).mainContent}
                    </div>
                    
                    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Connections Throughout Scripture</h4>
                      <p className="text-sm text-gray-700">
                        {getDetailedReflection(selectedVerse).connections}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;