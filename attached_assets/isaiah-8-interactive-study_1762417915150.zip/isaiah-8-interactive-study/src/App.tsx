import React, { useState } from 'react';
import './App.css';

interface Verse {
  number: number;
  text: string;
  group: number;
  isHinge?: boolean;
  hingeType?: string;
}

const verses: Verse[] = [
  // Sign and Timetable: Public verification and rapid fulfillment
  { number: 1, text: "Then the Lord said to me, \"Take a large tablet and write on it in common characters, 'Belonging to Maher-shalal-hash-baz.'\"", group: 1 },
  { number: 2, text: "And I will get reliable witnesses, Uriah the priest and Zechariah the son of Jeberechiah, to attest for me.", group: 1 },
  { number: 3, text: "And I went to the prophetess, and she conceived and bore a son. Then the Lord said to me, \"Call his name Maher-shalal-hash-baz;\"", group: 1 },
  { number: 4, text: "for before the boy knows how to cry 'My father' or 'My mother,' the wealth of Damascus and the spoil of Samaria will be carried away before the king of Assyria.", group: 1, isHinge: true, hingeType: 'timetable' },

  // Group 2: Waters Contrast (Teal)
  { number: 5, text: "The Lord spoke to me again:", group: 2 },
  { number: 6, text: "\"Because this people has refused the waters of Shiloah that flow gently, and rejoice over Rezin and the son of Remaliah,", group: 2 },
  { number: 7, text: "therefore, behold, the Lord is bringing up against them the waters of the River, mighty and many, the king of Assyria and all his glory. And it will rise over all its channels and go over all its banks,", group: 2, isHinge: true, hingeType: 'contrast' },
  { number: 8, text: "and it will sweep on into Judah, it will overflow and pass on, reaching even to the neck, and its outspread wings will fill the breadth of your land, O Immanuel.", group: 2, isHinge: true, hingeType: 'limit' },

  // Group 3: Nations/Counsel (Crimson Red)
  { number: 9, text: "Be broken, you peoples, and be shattered; give ear, all you far countries; strap on your armor and be shattered; strap on your armor and be shattered.", group: 3 },
  { number: 10, text: "Take counsel together, but it will come to nothing; speak a word, but it will not stand, for God is with us.", group: 3, isHinge: true, hingeType: 'presence' },

  // Group 4: Prophetic Instruction (Emerald Green)
  { number: 11, text: "For the Lord spoke thus to me with his strong hand upon me, and warned me not to walk in the way of this people, saying:", group: 4 },
  { number: 12, text: "\"Do not call conspiracy all that this people calls conspiracy, and do not fear what they fear, nor be in dread.", group: 4 },
  { number: 13, text: "But the Lord of hosts, him you shall honor as holy. Let him be your fear, and let him be your dread.", group: 4, isHinge: true, hingeType: 'sanctify' },

  // Group 5: Sanctuary vs. Stumbling (Amber/Gold)
  { number: 14, text: "And he will become a sanctuary and a stone of offense and a rock of stumbling to both houses of Israel, a trap and a snare to the inhabitants of Jerusalem.", group: 5, isHinge: true, hingeType: 'sanctuary' },
  { number: 15, text: "And many shall stumble on it. They shall fall and be broken; they shall be snared and taken.", group: 5 },

  // Group 6: Bind/Seal/Wait; Signs (Navy Blue)
  { number: 16, text: "Bind up the testimony; seal the teaching among my disciples.", group: 6, isHinge: true, hingeType: 'preserve' },
  { number: 17, text: "I will wait for the Lord, who is hiding his face from the house of Jacob, and I will hope in him.", group: 6 },
  { number: 18, text: "Behold, I and the children whom the Lord has given me are signs and portents in Israel from the Lord of hosts, who dwells on Mount Zion.", group: 6 },

  // Group 7: Word vs. Occult; Darkness (Charcoal Gray)
  { number: 19, text: "And when they say to you, \"Inquire of the mediums and the necromancers who chirp and mutter,\" should not a people inquire of their God? Should they inquire of the dead on behalf of the living?", group: 7 },
  { number: 20, text: "To the teaching and to the testimony! If they will not speak according to this word, it is because they have no dawn.", group: 7, isHinge: true, hingeType: 'testimony' },
  { number: 21, text: "They will pass through the land, greatly distressed and hungry. And when they are hungry, they will be enraged and will speak contemptuously against their king and their God, and turn their faces upward.", group: 7 },
  { number: 22, text: "And they will look to the earth, but behold, distress and darkness, the gloom of anguish. And they will be thrust into thick darkness.", group: 7 }
];

const getColorClass = (group: number): string => {
  const colors: Record<number, string> = {
    1: 'bg-blue-600',
    2: 'bg-teal-500', 
    3: 'bg-red-600',
    4: 'bg-green-600',
    5: 'bg-amber-500',
    6: 'bg-indigo-700',
    7: 'bg-gray-600'
  };
  return colors[group] || 'bg-gray-400';
};

const getGroupName = (group: number): string => {
  const names: Record<number, string> = {
    1: 'Sign and Timetable',
    2: 'Waters Contrast', 
    3: 'Nations/Counsel',
    4: 'Prophetic Instruction',
    5: 'Sanctuary vs. Stumbling',
    6: 'Bind/Seal/Wait; Signs',
    7: 'Word vs. Occult; Darkness'
  };
  return names[group] || 'Unknown Group';
};

const getGroupTransition = (group: number): string => {
  const transitions: Record<number, string> = {
    1: 'Public sign established - Maher-shalal-hash-baz with reliable witnesses',
    2: 'Contrast revealed - gentle Shiloah vs. overwhelming River flood',
    3: 'Nations confronted - human counsel fails, God with us prevails',
    4: 'Prophetic instruction - redirect fear to proper reverence for God',
    5: 'Dual outcome declared - sanctuary for faithful, stumbling for unbelief',
    6: 'Testimony preserved - bind up word, wait for God, family as signs',
    7: 'Choice presented - teaching/testimony vs. occult darkness'
  };
  return transitions[group] || 'Transition point in choosing God\'s way over human wisdom';
};

const reflectionContent = {
  1: {
    seeing: "This opening reveals God's method of making prophecy public and undeniable. The large tablet written in common characters shows God's desire for clarity and accessibility. This connects to how God's ways often involve visible, public demonstrations rather than hidden mysteries.",
    life: "God often calls us to make our faith visible and understandable to others. What 'large tablets' in your life—your actions, words, or commitments—make God's truth clear to those around you?",
    teach: "God's salvation plan is never meant to be hidden or exclusive. He seeks to make His truth accessible to all people through visible signs and clear communication."
  },
  2: {
    seeing: "The requirement for two witnesses establishes credibility and prevents false testimony. This principle appears throughout Scripture, showing God's commitment to truth and accountability.",
    life: "Our Christian testimony is strengthened when we have others who can confirm the authenticity of our faith. Who are the people who can attest that your life reflects God's truth?",
    teach: "Christian community serves as witnesses to God's work in individual lives. We are called to both seek and provide credible testimony about God's goodness."
  },
  3: {
    seeing: "The name 'Maher-shalal-hash-baz' means 'Swift to the spoil, quick to the plunder.' This prophetic name itself carries the message, showing how God sometimes uses our very identity as a testimony.",
    life: "Our names and identities can become testimonies to God's character. What aspects of who you are point others to God's speed, power, or faithfulness?",
    teach: "God can use our names, families, and circumstances as living testimonies. Sometimes our very identity becomes part of God's prophetic message to the world."
  },
  4: {
    seeing: "The rapid timetable—from birth to knowing 'father' and 'mother'—emphasizes the urgency and certainty of God's judgment. This shows how God works in specific, measurable timeframes.",
    life: "God often gives us clear timeframes for His work in our lives. Are you paying attention to the 'boy knows father/mother' moments in your own journey—those clear indicators that God's timing is at work?",
    teach: "God's timing is perfect but often urgent. The swift fulfillment of this prophecy reminds us that God's judgments and salvation come exactly when He intends them to."
  },
  5: {
    seeing: "This transition verse shows how God's word often comes to the prophet in repeated encounters. God's message is not always given all at once but revealed progressively.",
    life: "God often speaks to us repeatedly about the same issue before we fully understand or act. What is God saying to you right now that you've heard before?",
    teach: "God's patience in revealing His word shows His desire for us to understand. Sometimes we need multiple encounters with the same truth before we truly grasp it."
  },
  6: {
    seeing: "The contrast between 'waters of Shiloah' (gentle, local provision) and rejoicing over foreign alliances reveals humanity's tendency to prefer human solutions over God's faithful care.",
    life: "Like the Israelites, we often reject God's 'gentle provision' in favor of what seems stronger or more impressive from a human perspective. What 'Rezin and Remaliah' are you tempted to trust instead of God?",
    teach: "God's ways often appear small or gentle compared to worldly power, but His provision is always more reliable than human strength and alliances."
  },
  7: {
    seeing: "The 'waters of the River' represent overwhelming human power, specifically Assyria's might. This verse shows how human pride invites divine discipline through the very powers people trust.",
    life: "When we trust in worldly strength instead of God, we often find ourselves overwhelmed by the very powers we relied on. What 'mighty waters' are threatening to sweep over your life?",
    teach: "Human strength, when prioritized over God's power, becomes an instrument of judgment rather than protection. God's discipline often comes through the very forces we trust."
  },
  8: {
    seeing: "The image of affliction 'to the neck' shows God's sovereign limit on judgment. Even in discipline, God preserves His people. The title 'O Immanuel' ('God with us') anchors hope amid difficulty.",
    life: "God's judgments in your life have limits—He never abandons His children entirely. Even in discipline, can you recognize God's presence ('Immanuel') with you?",
    teach: "God's discipline is always bounded by His love. Even when life overwhelms us, God's presence ('God with us') provides hope and preservation."
  },
  9: {
    seeing: "This verse uses repetitive calls to nations to prepare for battle, only to immediately declare their failure. It shows how human preparations ultimately crumble before God's sovereignty.",
    life: "How much energy do you spend 'strapping on armor' for battles that God has already won? Sometimes our efforts to protect ourselves actually reveal our lack of trust in God's victory.",
    teach: "Human military preparations and strategic planning ultimately serve God's purposes, not their own. All human strength is subject to God's sovereign control."
  },
  10: {
    seeing: "This verse contains the great reversal: human counsel fails because 'God is with us.' The same 'Immanuel' promise that began with Ahaz now conquers all nations' plans.",
    life: "When human strategies and counsel seem overwhelming, remember that 'God is with us' is the ultimate reality. This truth can transform any circumstance.",
    teach: "The presence of God makes all human plans subject to His will. 'God with us' is not just a promise but a present reality that overrules every human scheme."
  },
  11: {
    seeing: "This verse begins a new section where God directly instructs the prophet about maintaining proper perspective. Sometimes we need God's strong hand to redirect our thinking.",
    life: "God's 'strong hand' often comes through circumstances that force us to reconsider our approach to life. Are you resisting His correction or learning from it?",
    teach: "God's corrections come through His strong hand, not gentle persuasion. Sometimes we need divine intervention to step away from patterns that lead us astray."
  },
  12: {
    seeing: "God redirects fear from political conspiracies to proper reverence. This shows how misplaced fear can consume our attention and energy.",
    life: "What 'conspiracies' in your life are stealing your peace? Sometimes our greatest enemy is not the people we fear, but our own misdirected anxieties.",
    teach: "God's people are called to fear God rather than fear people, circumstances, or political situations. True security comes from reverence for the Lord, not from analyzing threats."
  },
  13: {
    seeing: "The call to 'sanctify' God means to treat Him as holy, setting Him apart as the object of our fear and reverence. This rechannels all our anxieties toward proper worship.",
    life: "When fear overwhelms you, what would it look like to 'sanctify' God—to treat Him as holy and worthy of your ultimate attention and reverence?",
    teach: "God's holiness demands our primary fear and reverence. When we properly fear God, all other fears become manageable and put in proper perspective."
  },
  14: {
    seeing: "This verse presents one of Scripture's great paradoxes: the same Person becomes both refuge and stumbling block. This dual outcome depends on how people respond to Him.",
    life: "Jesus is either your sanctuary (place of safety) or your stumbling block (cause of offense). Which is He for you right now? Your answer determines your spiritual outcome.",
    teach: "Christ's dual outcome reflects the fundamental choice every person faces: accepting Him as Savior or rejecting Him as Savior. The outcome depends entirely on one's response."
  },
  15: {
    seeing: "The consequences are inevitable and severe: those who stumble over Jesus fall, are broken, and are taken captive. This shows the serious nature of spiritual choices.",
    life: "The choices you make about Jesus—receiving or rejecting Him—have eternal consequences. Are there areas in your life where you're still 'stumbling' over His claims?",
    teach: "Spiritual resistance leads to spiritual defeat. The only way to avoid being 'broken and taken' is to not stumble—to receive Christ as both sanctuary and Lord."
  },
  16: {
    seeing: "The call to 'bind up the testimony' and 'seal the teaching' shows God's commitment to preserving His word for future generations. This emphasizes the importance of preserving spiritual truth.",
    life: "What 'testimony' and 'teaching' are you responsible for preserving and passing on? Your spiritual legacy depends on how well you protect and share God's truth.",
    teach: "Each generation is responsible for preserving and passing on God's truth. The 'binding up' and 'sealing' of Scripture was accomplished through faithful messengers like Isaiah."
  },
  17: {
    seeing: "Waiting for God, even when He seems to hide His face, is an act of faith and hope. This posture contrasts with human tendencies to take matters into our own hands.",
    life: "When God seems distant or hidden, will you still wait for Him? Sometimes the most faithful action is patient waiting rather than frantic activity.",
    teach: "Waiting for God is not passive resignation but active faith. Even when God seems absent, we can hope in His promises and character."
  },
  18: {
    seeing: "Isaiah and his children become living testimonies, showing how our families can serve as continuing signs of God's faithfulness. This connects individual faith to family legacy.",
    life: "How is your family serving as 'signs and portents' of God's work? What legacy are you building that points others to God's faithfulness?",
    teach: "Our families and children can become living testimonies of God's grace. We have the privilege and responsibility of creating spiritual legacies that point others to God."
  },
  19: {
    seeing: "This verse exposes the ultimate error: seeking guidance from the dead rather than the living God. It shows how spiritual rebellion leads to increasingly desperate and destructive choices.",
    life: "What forms of 'guidance' are you seeking that don't come from God? Sometimes we turn to money, relationships, or achievements instead of seeking God's direction.",
    teach: "Seeking guidance from worldly sources instead of God is a form of spiritual idolatry. True wisdom comes only from consulting the living God."
  },
  20: {
    seeing: "The 'teaching and testimony' refers to God's written word as the standard of truth. This verse establishes the authority of Scripture over all human wisdom and spiritual experiences.",
    life: "How do you test the guidance you receive? Do you measure it against 'the teaching and testimony'—God's word—or by other standards like feelings or popular opinion?",
    teach: "God's written word is the ultimate authority for truth and guidance. All spiritual experiences and advice must be measured against Scripture."
  },
  21: {
    seeing: "The consequences of rejecting God's guidance lead to physical distress, spiritual rebellion, and ultimately turning away from God altogether. This shows the progressive nature of spiritual decline.",
    life: "When you ignore God's guidance, where does it lead? Often it begins with small compromises that escalate into major rebellions against God.",
    teach: "Rejecting God's guidance has cascading consequences. What begins as spiritual disobedience often progresses to physical distress and eventual rejection of God."
  },
  22: {
    seeing: "The final verse presents the ultimate darkness—not physical darkness but spiritual darkness where hope is extinguished. This is the natural result of rejecting God's light.",
    life: "Are you experiencing any 'thick darkness' in your life that might be the result of turning away from God's guidance? It's not too late to turn back to His light.",
    teach: "Spiritual darkness is the natural consequence of rejecting God's truth. But even from this darkness, God can bring light if we turn back to Him."
  }
};

const viewingModes = [
  { id: 'connections', label: 'Seeing Connections' },
  { id: 'life', label: 'How This Helps My Life' },
  { id: 'teaches', label: 'What This Teaches Us' }
];

function App() {
  const [activeMode, setActiveMode] = useState('connections');
  const [hoveredVerse, setHoveredVerse] = useState<number | null>(null);
  const [selectedVerse, setSelectedVerse] = useState<Verse | null>(null);

  const getReflectionContent = (verseNum: number) => {
    return reflectionContent[verseNum as keyof typeof reflectionContent] || {
      seeing: "This verse connects to the broader theme of choosing between God's way and human wisdom throughout Isaiah 8.",
      life: "Consider how this verse speaks to the choices you're making between divine guidance and human understanding in your own life.",
      teach: "This verse contributes to Isaiah 8's central message about the contrast between God's faithful provision and human rebellion."
    };
  };

  const getCurrentReflection = () => {
    if (!selectedVerse) return '';
    const content = getReflectionContent(selectedVerse.number);
    switch (activeMode) {
      case 'connections': return content.seeing;
      case 'life': return content.life;
      case 'teaches': return content.teach;
      default: return content.seeing;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Isaiah Chapter 8 Interactive Study</h1>
          <p className="text-lg text-gray-600 mb-4">Paths of God vs. Paths of Man</p>
          
          {/* Viewing Mode Buttons */}
          <div className="flex flex-wrap justify-center gap-2 mb-6">
            {viewingModes.map((mode) => (
              <button
                key={mode.id}
                onClick={() => setActiveMode(mode.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  activeMode === mode.id
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 hover:bg-blue-50 border border-gray-300'
                }`}
              >
                {mode.label}
              </button>
            ))}
          </div>

          {/* Color Legend */}
          <div className="bg-white rounded-lg p-4 shadow-md mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Pathway Choice Groups</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Array.from({ length: 7 }, (_, i) => i + 1).map((group) => (
                <div key={group} className="flex items-start gap-3">
                  <div className={`w-4 h-4 rounded mt-1 flex-shrink-0 ${getColorClass(group)}`}></div>
                  <div className="text-sm">
                    <div className="font-medium text-gray-800">{getGroupName(group)}</div>
                    <div className="text-gray-600 text-xs">{getGroupTransition(group)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Key Transformation Points */}
          <div className="bg-white rounded-lg p-4 shadow-md mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Key transformation points</h3>
            <div className="flex items-start gap-3">
              <div className="w-3 h-3 bg-yellow-400 rounded-full mt-1 flex-shrink-0"></div>
              <p className="text-sm text-gray-700">Yellow dots mark moments where everything changes—from bitter waters to holy waters, from human counsel to God's word, from confusion to clear pathways.</p>
            </div>
          </div>
        </div>

        {/* Verse Grid */}
        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-2 mb-8">
          {verses.map((verse) => (
            <div
              key={verse.number}
              className={`relative ${getColorClass(verse.group)} text-white rounded-lg p-2 text-center cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg ${
                hoveredVerse === verse.number ? 'ring-4 ring-yellow-300' : ''
              } ${selectedVerse?.number === verse.number ? 'ring-4 ring-blue-300' : ''}`}
              onMouseEnter={() => setHoveredVerse(verse.number)}
              onMouseLeave={() => setHoveredVerse(null)}
              onClick={() => setSelectedVerse(verse)}
            >
              <div className="text-xs font-bold">8:{verse.number}</div>
              {verse.isHinge && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
              )}
              
              {/* Hover Tooltip */}
              {hoveredVerse === verse.number && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-80 bg-gray-800 text-white p-3 rounded-lg shadow-xl z-50 text-sm">
                  <div className="font-semibold text-yellow-300 mb-1">Isaiah 8:{verse.number}</div>
                  <div className="text-gray-100 mb-2">{verse.text}</div>
                  <div className="text-xs text-yellow-300 mb-1">{getGroupName(verse.group)}</div>
                  <div className="text-xs text-gray-300 mb-2">{getGroupTransition(verse.group)}</div>
                  {verse.isHinge && (
                    <div className="text-xs text-yellow-300 mt-1">• Structural Transition Point</div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Detailed Reflection Modal */}
        {selectedVerse && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-bold text-gray-800">
                    Isaiah 8:{selectedVerse.number} - {getGroupName(selectedVerse.group)}
                  </h3>
                  <button
                    onClick={() => setSelectedVerse(null)}
                    className="text-gray-500 hover:text-gray-700 text-2xl"
                  >
                    ×
                  </button>
                </div>
                
                <div className="mb-4">
                  <div className={`inline-block ${getColorClass(selectedVerse.group)} text-white px-3 py-1 rounded-full text-sm font-medium`}>
                    {getGroupName(selectedVerse.group)}
                  </div>
                  {selectedVerse.isHinge && (
                    <span className="ml-2 inline-block bg-yellow-400 text-yellow-900 px-2 py-1 rounded-full text-xs font-bold">
                      Hinge Point
                    </span>
                  )}
                </div>

                <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-2">ESV Text:</h4>
                  <p className="text-gray-700 italic">{selectedVerse.text}</p>
                </div>

                <div className="mb-4">
                  <div className="flex gap-2 mb-4">
                    {viewingModes.map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => setActiveMode(mode.id)}
                        className={`px-3 py-1 rounded text-sm font-medium ${
                          activeMode === mode.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                      >
                        {mode.label}
                      </button>
                    ))}
                  </div>
                  
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">
                      {viewingModes.find(m => m.id === activeMode)?.label}:
                    </h4>
                    <p className="text-gray-700">{getCurrentReflection()}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;