import React from 'react';
import './App.css';

interface ViewingMode {
  id: string;
  title: string;
  description: string;
}

const viewingModes: ViewingMode[] = [
  {
    id: 'connections',
    title: 'Seeing Connections',
    description: 'How this verse connects to chapters 3, 5, and 6'
  },
  {
    id: 'life',
    title: 'How This Helps My Life',
    description: 'Spiritual insights about God\'s restoration'
  },
  {
    id: 'teaching',
    title: 'What This Teaches Us',
    description: 'Transformation from desperation to hope'
  }
];

const verseText = "And seven women shall take hold of one man in that day, saying, \"We will eat our own bread and wear our own clothes, only let us be called by your name; take away our reproach.\" (Isaiah 4:1, ESV)";

function App() {
  const [activeViewingMode, setActiveViewingMode] = React.useState<string>('connections');
  const [selectedVerse, setSelectedVerse] = React.useState<string | null>(null);

  const getTooltipContent = (mode: string) => {
    switch (mode) {
      case 'connections':
        return {
          title: 'Seeing Connections',
          content: 'This verse sits at the turning point between judgment and hope. It follows directly after chapter 3, where devastation and shame have left people desperate. It opens the door to chapter 4\'s promise of cleansing and God\'s presence, and sets up the journey toward the royal hope we see later in Isaiah\'s prophecy.'
        };
      case 'life':
        return {
          title: 'How This Helps My Life',
          content: 'Sometimes we find ourselves in places where we desperately need security, identity, and hope. This verse reminds us that God sees our deepest needs and promises restoration. Even when everything feels uncertain, God provides a way from shame to honor, from isolation to belonging, and from desperation to hope.'
        };
      case 'teaching':
        return {
          title: 'What This Teaches Us',
          content: 'God\'s people move from the lowest point—desperation and shame—to the highest promise—glory and honor. This verse teaches us that no situation is beyond God\'s transforming power. What seems like an ending can become a doorway to God\'s greater purposes and promises.'
        };
      default:
        return { title: '', content: '' };
    }
  };

  const getColorClass = (group: number) => {
    const colorMap: { [key: number]: string } = {
      1: 'bg-gradient-to-br from-red-500 to-red-600',
      2: 'bg-gradient-to-br from-teal-500 to-teal-600',
      3: 'bg-gradient-to-br from-amber-600 to-amber-700',
      4: 'bg-gradient-to-br from-blue-800 to-blue-900',
      5: 'bg-gradient-to-br from-sky-400 to-slate-500',
      6: 'bg-gradient-to-br from-emerald-500 to-emerald-600'
    };
    return colorMap[group] || 'bg-gray-500';
  };

  const getDetailedReflection = () => ({
    title: "Finding Hope in God's Restoration",
    mainContent: `This single verse captures a pivotal moment when the worst has happened, but God's people are about to experience His restoring grace.

**What This Means for Your Life:**
- God sees your deepest moments of need and shame
- He promises to remove reproach and give you honor
- Your identity comes from belonging to Him, not from your circumstances
- In your darkest moments, God is already preparing restoration

**Questions for Reflection:**
- Where do you feel like the women in this verse—needing security and honor?
- How has God shown you His restoring love in difficult seasons?
- What does it mean to you that God wants to "call you by His name"?
- How can you trust God's promises even when circumstances look desperate?

**How This Applies to Daily Life:**
This verse reminds us that God specializes in turning situations around. When we feel like we're at our lowest point, we can trust that God sees our needs and has a plan for restoration. His promise to "call us by His name" means we are forever secure in His family.

**What God is Teaching Us Here:**
God's people don't stay in shame forever. He transforms desperation into hope, isolation into belonging, and reproach into honor. This is the heart of the Gospel—God takes our brokenness and makes us His beloved children.`,
    connections: `This verse connects beautifully with the larger story:

- **Chapter 3 Context**: Sets up the desperate situation that leads to this plea
- **Chapter 4:2-6**: Shows God's answer through cleansing and His presence
- **Forward to Chapter 9**: Points toward the royal hope and joy that will come`
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Isaiah Chapter 4 Interactive Study</h1>
          <p className="text-lg text-gray-600">A Single Verse That Changes Everything</p>
        </div>

        {/* Verse Display */}
        <div className="grid justify-center mb-12">
          <div 
            className={`
              relative w-64 h-40 rounded-xl shadow-lg cursor-pointer group
              bg-gradient-to-br from-red-500 to-red-600
              transform hover:scale-105 transition-all duration-300
              flex items-center justify-center
            `}
            onClick={() => setSelectedVerse('4:1')}
          >
            <div className="text-center text-white">
              <div className="text-2xl font-bold mb-2">Isaiah 4:1</div>
              <div className="text-sm opacity-90">Click for reflection</div>
            </div>
            
            {/* Hover Tooltip */}
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-4 opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none group-hover:opacity-100">
              <div className="bg-white rounded-lg shadow-xl p-4 w-80 border relative">
                <div className="text-xs font-semibold text-gray-500 mb-2">
                  {getTooltipContent(activeViewingMode).title}
                </div>
                <div className="text-sm text-gray-700 mb-3">
                  {verseText}
                </div>
                <div className="text-sm text-gray-600">
                  {getTooltipContent(activeViewingMode).content}
                </div>
                {/* Tooltip arrow */}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 -translate-y-1 w-0 h-0 border-l-8 border-r-8 border-t-8 border-l-transparent border-r-transparent border-t-white"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Viewing Mode Selector */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-2 shadow-md">
            {viewingModes.map((mode) => (
              <button
                key={mode.id}
                onClick={() => setActiveViewingMode(mode.id)}
                className={`
                  px-4 py-2 mx-1 rounded-md text-sm font-medium transition-colors
                  ${activeViewingMode === mode.id 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }
                `}
              >
                {mode.title}
              </button>
            ))}
          </div>
        </div>

        {/* Color Legend */}
        <div className="bg-white rounded-lg p-6 shadow-md mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">How This Verse Connects</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { group: 1, title: 'Desperation & Need', desc: 'The plea for name and honor' },
              { group: 2, title: 'Cleansing & Holiness', desc: 'God\'s restoring work begins' },
              { group: 3, title: 'Growing Toward Hope', desc: 'The journey toward joy and peace' }
            ].map((item) => (
              <div key={item.group} className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded ${getColorClass(item.group)}`}></div>
                <div>
                  <div className="font-medium text-gray-900">Group {item.group}</div>
                  <div className="text-sm text-gray-600">{item.title} - {item.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Transformation Points */}
        <div className="bg-white rounded-lg p-4 shadow-md mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Key transformation points</h3>
          <div className="flex items-start gap-3">
            <div className="w-3 h-3 bg-yellow-400 rounded-full mt-1 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">Yellow dots mark moments where everything changes—from stain to cleansing, from wilderness to refuge, from exile to holy calling.</p>
          </div>
        </div>

        {/* Detailed Reflection Modal */}
        {selectedVerse && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">
                    Isaiah 4:1 - Detailed Reflection
                  </h2>
                  <button
                    onClick={() => setSelectedVerse(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>
                
                <div className="prose max-w-none">
                  {(() => {
                    const reflection = getDetailedReflection();
                    return (
                      <div>
                        <div className="text-sm text-gray-500 mb-4 italic">
                          {verseText}
                        </div>
                        
                        <div className="whitespace-pre-line">
                          {reflection.mainContent}
                        </div>
                        
                        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                          <h4 className="font-semibold text-gray-900 mb-2">Connections Throughout Scripture</h4>
                          <p className="text-sm text-gray-700">
                            {reflection.connections}
                          </p>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;