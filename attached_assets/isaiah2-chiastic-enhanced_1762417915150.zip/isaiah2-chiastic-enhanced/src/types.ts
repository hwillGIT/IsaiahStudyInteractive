// Enhanced Types for Isaiah 2 Biblical Study Guide

export type AnalysisMode = 'structure_focus' | 'life_application' | 'compare_modes';
export type ViewMode = 'overview' | 'detail';

export interface ColorCode {
  id: string;
  name: string;
  description: string;
  theme: string;
  base_color: string;
  hover_color: string;
  ring_color: string;
  verses: number[];
}

export interface VerseColorAssignment {
  primary_color: string;
  secondary_colors: string[];
  anti_pair_verses: number[];
  structural_pair_verses: number[];
}

export interface Verse {
  verse: number;
  text: string;
  main_point: string;
  insights: {
    structure: string;
    application: string;
  };
  what_you_see: string;
  is_hinge?: boolean;
  section_type?: string;
  color_assignments: VerseColorAssignment;
  detailed_analysis: {
    structure_focus: string;
    life_application: string;
    compare_analysis: string;
  };
}

export interface ViewingMode {
  name: string;
  description: string;
  emphasis: string;
}

export interface StructuralInsights {
  anti_pairs: {
    [key: string]: string;
  };
  repeated_motifs: {
    [key: string]: string;
  };
}

export interface Isaiah2EnhancedData {
  title: string;
  subtitle: string;
  version: string;
  color_codes: ColorCode[];
  verses: Verse[];
  viewing_modes: {
    structure_focus: ViewingMode;
    life_application: ViewingMode;
    compare_modes: ViewingMode;
  };
  structural_insights: StructuralInsights;
}

// Legacy types for backward compatibility (not used in new structure)
export interface MicroStructurePair {
  elements: string[];
  content: string;
  color: 'idols' | 'terror' | 'catalogue';
}

export interface RepeatedMotif {
  pattern: string;
  verses: number[];
  progression?: string;
  significance?: string;
}

export interface Section {
  id: string;
  title: string;
  verse_range: string;
  description: string;
  color_scheme: 'golden' | 'dark';
  theme: 'hope' | 'warning';
  how_it_flows?: {
    movement?: string;
    story_line?: string;
  };
  three_parts?: {
    type: string;
    structure: string;
    parts: MicroStructurePair[];
  };
  patterns?: RepeatedMotif[];
  verses: Verse[];
}

export interface Hinge {
  verse: number;
  text: string;
  function: string;
  significance: string;
}

export interface StructuralPair {
  element: string;
  section_a: string;
  section_b: string;
  visual: string;
  meaning: string;
}

export interface KeyInsights {
  main_point: string;
  hope_way: string;
  warning_way: string;
  repeated_pattern: string;
  writing_technique: string;
}

export interface OverallStructure {
  title: string;
  description: string;
  hinge: Hinge;
}