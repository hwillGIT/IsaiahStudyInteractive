import React from 'react';
import { Grid3X3, BarChart3, Layers } from 'lucide-react';
import type { ViewMode } from '../types';

interface ViewModeToggleProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
}

const ViewModeToggle: React.FC<ViewModeToggleProps> = ({
  viewMode,
  setViewMode,
}) => {
  const modes = [
    {
      id: 'overview' as ViewMode,
      label: 'Overview',
      icon: Grid3X3,
      description: 'See the big picture'
    },
    {
      id: 'line-by-line' as ViewMode,
      label: 'Explore',
      icon: BarChart3,
      description: 'Line-by-line study'
    },
    {
      id: 'discover' as ViewMode,
      label: 'Discover',
      icon: Layers,
      description: 'How it all connects'
    }
  ];

  return (
    <div className="bg-white rounded-lg border border-amber-200 shadow-md p-1 flex">
      {modes.map((mode) => {
        const Icon = mode.icon;
        const isActive = viewMode === mode.id;
        
        return (
          <button
            key={mode.id}
            onClick={() => setViewMode(mode.id)}
            className={`px-4 py-3 rounded-md text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
              isActive
                ? 'bg-orange-600 text-white shadow-sm'
                : 'text-orange-700 hover:bg-orange-50'
            }`}
            title={`${mode.label} View - ${mode.description}`}
          >
            <Icon className="w-4 h-4" />
            <span className="font-medium">{mode.label}</span>
          </button>
        );
      })}
    </div>
  );
};

export default ViewModeToggle;