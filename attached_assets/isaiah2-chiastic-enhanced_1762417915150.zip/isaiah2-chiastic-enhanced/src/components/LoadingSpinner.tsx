import React from 'react';
import { BookOpen } from 'lucide-react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 flex items-center justify-center">
      <div className="text-center">
        <div className="relative mb-6">
          <BookOpen className="w-16 h-16 text-amber-600 animate-pulse mx-auto" />
          <div className="absolute inset-0 rounded-full border-4 border-amber-200 border-t-amber-600 animate-spin"></div>
        </div>
        <h2 className="text-2xl font-bold text-amber-900 mb-2">Loading Isaiah 2 Analysis</h2>
        <p className="text-amber-700">Preparing the interactive chiastic visualization...</p>
      </div>
    </div>
  );
};

export default LoadingSpinner;