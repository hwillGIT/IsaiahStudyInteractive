import React from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Eye, Heart, GitCompare } from 'lucide-react';
import type { Isaiah2EnhancedData, Verse, AnalysisMode, ColorCode } from '../types';

interface VerseDetailProps {
  data: Isaiah2EnhancedData;
  selectedVerse: number;
  onVerseChange: (verseNumber: number) => void;
  analysisMode: AnalysisMode;
  onBackToOverview: () => void;
}

const VerseDetail: React.FC<VerseDetailProps> = ({
  data,
  selectedVerse,
  onVerseChange,
  analysisMode,
  onBackToOverview,
}) => {
  const verse = data.verses.find(v => v.verse === selectedVerse);
  if (!verse) return null;

  const primaryColor = data.color_codes.find(c => c.id === verse.color_assignments.primary_color);
  const secondaryColors = verse.color_assignments.secondary_colors
    .map(colorId => data.color_codes.find(c => c.id === colorId))
    .filter(Boolean) as ColorCode[];

  const handlePrevVerse = () => {
    if (selectedVerse > 1) {
      onVerseChange(selectedVerse - 1);
    }
  };

  const handleNextVerse = () => {
    if (selectedVerse < 22) {
      onVerseChange(selectedVerse + 1);
    }
  };

  const getAnalysisContent = () => {
    switch (analysisMode) {
      case 'structure_focus':
        return {
          icon: <Eye className="w-6 h-6" />,
          title: 'Structural Analysis',
          color: 'blue',
          content: verse.detailed_analysis.structure_focus,
          insight: verse.insights.structure
        };
      case 'life_application':
        return {
          icon: <Heart className="w-6 h-6" />,
          title: 'Life Application',
          color: 'emerald',
          content: verse.detailed_analysis.life_application,
          insight: verse.insights.application
        };
      case 'compare_modes':
        return {
          icon: <GitCompare className="w-6 h-6" />,
          title: 'Compare Analysis',
          color: 'purple',
          content: verse.detailed_analysis.compare_analysis,
          insight: verse.what_you_see
        };
      default:
        return {
          icon: <Eye className="w-6 h-6" />,
          title: 'Analysis',
          color: 'gray',
          content: verse.text,
          insight: verse.main_point
        };
    }
  };

  const analysis = getAnalysisContent();

  const getRelatedVerses = () => {
    const antiPairs = verse.color_assignments.anti_pair_verses
      .map(v => data.verses.find(verse => verse.verse === v))
      .filter(Boolean);
    
    const structuralPairs = verse.color_assignments.structural_pair_verses
      .map(v => data.verses.find(verse => verse.verse === v))
      .filter(Boolean);
    
    return { antiPairs, structuralPairs };
  };

  const { antiPairs, structuralPairs } = getRelatedVerses();

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header with Navigation */}
      <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={onBackToOverview}
            className="flex items-center gap-2 text-amber-700 hover:text-amber-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Overview
          </button>
          
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full bg-${analysis.color}-100 border border-${analysis.color}-300`}>
              <div className={`text-${analysis.color}-600`}>
                {analysis.icon}
              </div>
              <span className={`font-medium text-${analysis.color}-900`}>
                {analysis.title}
              </span>
            </div>
          </div>
        </div>

        {/* Verse Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevVerse}
            disabled={selectedVerse === 1}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all
              ${selectedVerse === 1 
                ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' 
                : 'bg-white text-amber-700 border-amber-300 hover:bg-amber-50'
              }`}
          >
            <ChevronLeft className="w-4 h-4" />
            {selectedVerse > 1 ? `Verse ${selectedVerse - 1}` : 'First Verse'}
          </button>

          <div className="text-center">
            <div className="text-3xl font-bold text-amber-900">Verse {selectedVerse}</div>
            <div className="text-sm text-amber-700">
              {verse.is_hinge ? 'The Hinge Point' : selectedVerse <= 5 ? 'Vision Section' : 'Warning Section'}
            </div>
          </div>

          <button
            onClick={handleNextVerse}
            disabled={selectedVerse === 22}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all
              ${selectedVerse === 22 
                ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' 
                : 'bg-white text-amber-700 border-amber-300 hover:bg-amber-50'
              }`}
          >
            {selectedVerse < 22 ? `Verse ${selectedVerse + 1}` : 'Last Verse'}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Verse Content */}
      <div className={`${primaryColor?.base_color || 'bg-gray-100'} rounded-xl border-2 ${primaryColor?.hover_color.replace('bg-', 'border-') || 'border-gray-300'} shadow-lg p-8`}>
        {/* Color Indicators */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <div className={`w-6 h-6 rounded-lg border-2 ${primaryColor?.base_color || 'bg-gray-100'}`}></div>
            <span className="font-medium text-gray-900">{primaryColor?.name || 'Unknown'}</span>
            <span className="text-sm text-gray-600">({primaryColor?.theme || 'Theme'})</span>
          </div>
          
          {secondaryColors.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Also:</span>
              {secondaryColors.map((color, index) => (
                <div key={color.id} className="flex items-center gap-1">
                  <div className={`w-4 h-4 rounded border ${color.base_color}`}></div>
                  <span className="text-xs text-gray-600">{color.name}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ESV Text */}
        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-2">ESV Text:</div>
          <blockquote className="text-lg leading-relaxed text-gray-800 font-serif italic bg-white bg-opacity-50 p-4 rounded-lg border-l-4 border-amber-400">
            "{verse.text}"
          </blockquote>
        </div>

        {/* Main Point */}
        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-2">Key Message:</div>
          <div className="text-lg font-medium text-gray-900">
            {verse.main_point}
          </div>
        </div>

        {/* Analysis Content */}
        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-2">{analysis.title}:</div>
          <div className="text-gray-800 leading-relaxed">
            {analysis.content}
          </div>
        </div>

        {/* Additional Insight */}
        <div className="bg-white bg-opacity-60 rounded-lg p-4 border border-amber-200">
          <div className="text-sm font-medium text-gray-700 mb-2">Additional Insight:</div>
          <div className="text-gray-800">
            {analysis.insight}
          </div>
        </div>
      </div>

      {/* Related Verses */}
      {(antiPairs.length > 0 || structuralPairs.length > 0) && (
        <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-6">
          <h3 className="text-xl font-semibold text-amber-900 mb-4">Related Verses</h3>
          
          {antiPairs.length > 0 && (
            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3">Anti-Pair Relationships</h4>
              <div className="space-y-3">
                {antiPairs.map((relatedVerse) => (
                  <div 
                    key={relatedVerse.verse}
                    className="flex items-start gap-4 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => onVerseChange(relatedVerse.verse)}
                  >
                    <div className="w-8 h-8 bg-red-100 border-2 border-red-300 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-red-800">{relatedVerse.verse}</span>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{relatedVerse.main_point}</div>
                      <div className="text-sm text-gray-600 mt-1">{relatedVerse.text.substring(0, 100)}...</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {structuralPairs.length > 0 && (
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Structural Pairs</h4>
              <div className="space-y-3">
                {structuralPairs.map((relatedVerse) => (
                  <div 
                    key={relatedVerse.verse}
                    className="flex items-start gap-4 p-3 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors"
                    onClick={() => onVerseChange(relatedVerse.verse)}
                  >
                    <div className="w-8 h-8 bg-blue-100 border-2 border-blue-300 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-blue-800">{relatedVerse.verse}</span>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{relatedVerse.main_point}</div>
                      <div className="text-sm text-gray-600 mt-1">{relatedVerse.text.substring(0, 100)}...</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default VerseDetail;