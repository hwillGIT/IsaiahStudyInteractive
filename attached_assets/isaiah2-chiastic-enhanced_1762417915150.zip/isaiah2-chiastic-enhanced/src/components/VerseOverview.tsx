import React, { useState } from 'react';
import type { Isaiah2EnhancedData, Verse, ColorCode, AnalysisMode } from '../types';

interface VerseOverviewProps {
  data: Isaiah2EnhancedData;
  selectedVerse: number | null;
  onVerseSelect: (verseNumber: number) => void;
  analysisMode: AnalysisMode;
  onAnalysisModeChange: (mode: AnalysisMode) => void;
}

interface VerseBlockProps {
  verse: Verse;
  colorCodes: ColorCode[];
  isSelected: boolean;
  isHighlighted: boolean;
  onClick: () => void;
  onHover: () => void;
  onLeave: () => void;
  analysisMode: AnalysisMode;
}

const VerseBlock: React.FC<VerseBlockProps> = ({
  verse,
  colorCodes,
  isSelected,
  isHighlighted,
  onClick,
  onHover,
  onLeave,
  analysisMode,
}) => {
  const getPrimaryColor = () => {
    const primaryColorCode = colorCodes.find(c => c.id === verse.color_assignments.primary_color);
    return primaryColorCode || colorCodes[0];
  };

  const getSecondaryColors = () => {
    return verse.color_assignments.secondary_colors.map(colorId => 
      colorCodes.find(c => c.id === colorId)
    ).filter(Boolean);
  };

  const primaryColor = getPrimaryColor();
  const secondaryColors = getSecondaryColors();

  const getBlockStyles = () => {
    if (isHighlighted) {
      return primaryColor.hover_color;
    }
    return primaryColor.base_color;
  };

  const getRingStyles = () => {
    if (isSelected) {
      return `ring-2 ${primaryColor.ring_color} ring-opacity-80 scale-105`;
    }
    return '';
  };

  const getTooltipContent = () => {
    switch (analysisMode) {
      case 'structure_focus':
        return {
          title: `Structural Analysis - Verse ${verse.verse}`,
          content: verse.detailed_analysis.structure_focus,
          extra: `Theme: ${primaryColor.theme}`
        };
      case 'life_application':
        return {
          title: `Life Application - Verse ${verse.verse}`,
          content: verse.detailed_analysis.life_application,
          extra: verse.main_point
        };
      case 'compare_modes':
        return {
          title: `Compare Analysis - Verse ${verse.verse}`,
          content: verse.detailed_analysis.compare_analysis,
          extra: `Anti-pairs: ${verse.color_assignments.anti_pair_verses.join(', ') || 'None'}`
        };
      default:
        return {
          title: `Verse ${verse.verse}`,
          content: verse.text,
          extra: verse.main_point
        };
    }
  };

  const tooltip = getTooltipContent();

  return (
    <div
      className={`
        ${getBlockStyles()}
        ${getRingStyles()}
        ${verse.is_hinge ? 'ring-1 ring-orange-500 ring-opacity-70' : ''}
        relative w-14 h-14 rounded-xl border-2 cursor-pointer
        transition-all duration-300 ease-in-out
        hover:scale-110 hover:shadow-lg hover:z-10
        flex items-center justify-center
        group
      `}
      onClick={onClick}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      {/* Verse Number */}
      <span className="text-lg font-bold text-gray-800 z-10 relative">
        {verse.verse}
      </span>
      
      {/* Secondary Color Indicators */}
      {secondaryColors.length > 0 && (
        <div className="absolute -top-1 -right-1 flex gap-1">
          {secondaryColors.map((color, index) => (
            <div 
              key={color?.id} 
              className={`w-2 h-2 ${color?.base_color.replace('bg-', 'bg-').replace('border-', 'bg-')} rounded-full border border-white`}
              style={{ transform: `translateX(${index * -4}px)` }}
            />
          ))}
        </div>
      )}

      {/* Hinge Indicator */}
      {verse.is_hinge && (
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-orange-500 rounded-full border-2 border-white shadow-md">
          <div className="w-1 h-1 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
        </div>
      )}

      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-3 px-4 py-3 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-30 whitespace-nowrap max-w-xs shadow-xl">
        <div className="font-semibold mb-2 text-amber-200">{tooltip.title}</div>
        <div className="text-gray-200 mb-2 leading-relaxed max-w-xs whitespace-normal">
          {tooltip.content}
        </div>
        <div className="text-gray-400 text-xs border-t border-gray-700 pt-1">
          {tooltip.extra}
        </div>
        {/* Tooltip arrow */}
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
      </div>
    </div>
  );
};

const VerseOverview: React.FC<VerseOverviewProps> = ({
  data,
  selectedVerse,
  onVerseSelect,
  analysisMode,
  onAnalysisModeChange,
}) => {
  const [hoveredVerse, setHoveredVerse] = useState<number | null>(null);

  // Get all verses sorted by number
  const allVerses = data.verses.sort((a, b) => a.verse - b.verse);

  const isHighlighted = (verse: Verse): boolean => {
    if (!hoveredVerse) return false;
    
    const hoveredVerseData = allVerses.find(v => v.verse === hoveredVerse);
    if (!hoveredVerseData) return false;
    
    // Highlight if this verse is in anti-pair or structural pair relationship
    return (
      hoveredVerseData.color_assignments.anti_pair_verses.includes(verse.verse) ||
      hoveredVerseData.color_assignments.structural_pair_verses.includes(verse.verse) ||
      verse.verse === hoveredVerse
    );
  };

  const getViewingModeDescription = () => {
    return data.viewing_modes[analysisMode];
  };

  const viewingMode = getViewingModeDescription();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-amber-900">Isaiah 2 Interactive Study</h2>
        <p className="text-lg text-amber-700 max-w-4xl mx-auto">
          {data.subtitle}
        </p>
      </div>

      {/* Analysis Mode Toggle */}
      <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-6">
        <h3 className="text-xl font-semibold text-amber-900 mb-4">Choose Your Analysis Mode</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {Object.entries(data.viewing_modes).map(([mode, config]) => (
            <button
              key={mode}
              onClick={() => onAnalysisModeChange(mode as AnalysisMode)}
              className={`
                p-4 rounded-lg border-2 text-left transition-all duration-200
                ${analysisMode === mode 
                  ? 'border-amber-400 bg-amber-50 shadow-md' 
                  : 'border-gray-200 bg-white hover:border-amber-300 hover:bg-amber-25'
                }
              `}
            >
              <div className="font-semibold text-amber-900 mb-2">{config.name}</div>
              <div className="text-sm text-gray-600 mb-2">{config.description}</div>
              <div className="text-xs text-amber-700 italic">{config.emphasis}</div>
            </button>
          ))}
        </div>
        
        {/* Current Mode Display */}
        <div className="mt-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
          <div className="font-medium text-amber-900">Active Mode: {viewingMode?.name}</div>
          <div className="text-sm text-amber-700 mt-1">{viewingMode?.description}</div>
        </div>
      </div>

      {/* Color Legend */}
      <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-6">
        <h3 className="text-xl font-semibold text-amber-900 mb-4">8-Color Structural System</h3>
        <p className="text-sm text-gray-600 mb-4">Colors show structural pairs and anti-pair relationships in the chiastic structure</p>
        
        <div className="grid md:grid-cols-4 lg:grid-cols-4 gap-4">
          {data.color_codes.map((color) => (
            <div key={color.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
              <div className={`w-6 h-6 rounded-lg border-2 ${color.base_color} flex-shrink-0`}></div>
              <div className="min-w-0">
                <div className="font-medium text-gray-900 text-sm">{color.name}</div>
                <div className="text-xs text-gray-600">{color.theme}</div>
                <div className="text-xs text-gray-500">vv {color.verses.join(', ')}</div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-200 flex items-center gap-6 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-orange-500 rounded-full border-2 border-white"></div>
            <span>Hinge Point (v.5)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-400 rounded border-2 border-blue-500"></div>
            <span>Selected Verse</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
            <span>Secondary Color</span>
          </div>
        </div>
      </div>

      {/* 22-Verse Grid */}
      <div className="bg-gradient-to-br from-amber-50 via-white to-orange-50 rounded-xl border border-amber-200 shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-amber-900">All 22 Verses - Unified Grid</h3>
          <div className="text-sm text-amber-700 bg-amber-200 px-3 py-1 rounded-full">
            Hover to see pairs • Click for details
          </div>
        </div>
        
        {/* Grid Container */}
        <div className="grid grid-cols-6 md:grid-cols-8 lg:grid-cols-11 gap-4 justify-items-center">
          {allVerses.map((verse) => (
            <VerseBlock
              key={verse.verse}
              verse={verse}
              colorCodes={data.color_codes}
              isSelected={selectedVerse === verse.verse}
              isHighlighted={isHighlighted(verse)}
              onClick={() => onVerseSelect(verse.verse)}
              onHover={() => setHoveredVerse(verse.verse)}
              onLeave={() => setHoveredVerse(null)}
              analysisMode={analysisMode}
            />
          ))}
        </div>
        
        {/* Grid Instructions */}
        <div className="mt-6 text-center space-y-2">
          <p className="text-sm text-amber-700">
            Colors show structural relationships • Hover to highlight connected verses
          </p>
          <p className="text-xs text-gray-600">
            Current mode: <span className="font-medium">{viewingMode?.name}</span> - 
            {analysisMode === 'structure_focus' && ' See how verses mirror and pair structurally'}
            {analysisMode === 'life_application' && ' Discover practical insights for daily life'}
            {analysisMode === 'compare_modes' && ' Compare themes and relationships between sections'}
          </p>
        </div>
      </div>

      {/* Anti-Pair Relationships */}
      <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-6">
        <h3 className="text-xl font-semibold text-amber-900 mb-4">Key Structural Relationships</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-amber-800 mb-2">Anti-Pair Themes</h4>
            <div className="space-y-2 text-sm">
              {Object.entries(data.structural_insights.anti_pairs).map(([key, description]) => (
                <div key={key} className="text-gray-700">
                  <span className="font-medium capitalize">{key.replace('_', ' ')}: </span>
                  {description}
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-amber-800 mb-2">Repeated Motifs</h4>
            <div className="space-y-2 text-sm">
              {Object.entries(data.structural_insights.repeated_motifs).map(([key, description]) => (
                <div key={key} className="text-gray-700">
                  <span className="font-medium capitalize">{key.replace('_', ' ')}: </span>
                  {description}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VerseOverview;