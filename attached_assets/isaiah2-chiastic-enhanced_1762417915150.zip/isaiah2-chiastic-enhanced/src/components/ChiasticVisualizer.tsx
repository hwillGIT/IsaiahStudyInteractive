import React, { useState } from 'react';
import { Crown, Shield, Eye } from 'lucide-react';
import type { Isaiah2EnhancedData, AnalysisMode } from '../types';
import VerseOverview from './VerseOverview';
import VerseDetail from './VerseDetail';

interface ChiasticVisualizerProps {
  data: Isaiah2EnhancedData;
}

const ChiasticVisualizer: React.FC<ChiasticVisualizerProps> = ({ data }) => {
  const [selectedVerse, setSelectedVerse] = useState<number | null>(null);
  const [currentView, setCurrentView] = useState<'overview' | 'detail'>('overview');
  const [analysisMode, setAnalysisMode] = useState<AnalysisMode>('structure_focus');

  const handleVerseSelect = (verseNumber: number) => {
    setSelectedVerse(verseNumber);
    setCurrentView('detail');
  };

  const handleVerseChange = (verseNumber: number) => {
    setSelectedVerse(verseNumber);
  };

  const handleBackToOverview = () => {
    setCurrentView('overview');
    setSelectedVerse(null);
  };

  const handleAnalysisModeChange = (mode: AnalysisMode) => {
    setAnalysisMode(mode);
  };

  // Show detail view when a verse is selected
  if (currentView === 'detail' && selectedVerse) {
    return (
      <VerseDetail
        data={data}
        selectedVerse={selectedVerse}
        onVerseChange={handleVerseChange}
        analysisMode={analysisMode}
        onBackToOverview={handleBackToOverview}
      />
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-bold text-amber-900">{data.title}</h1>
        <p className="text-xl text-amber-700 max-w-4xl mx-auto">{data.subtitle}</p>
        <div className="text-sm text-gray-600 bg-gray-100 px-4 py-2 rounded-full inline-block">
          {data.version}
        </div>
      </div>

      {/* Quick Structure Overview */}
      <div className="bg-gradient-to-r from-amber-100 via-orange-50 to-red-50 rounded-xl border-2 border-amber-200 p-8">
        <div className="text-center mb-6">
          <h2 className="text-3xl font-bold text-amber-900 mb-2">Two Connected Parts</h2>
          <p className="text-amber-800 text-lg">Part One shows God's vision for the world; Part Two shows what gets in the way</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 items-center">
          {/* Vision Section (1-4) */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-yellow-100 to-amber-100 border border-yellow-300 rounded-xl p-6 mb-4 shadow-md">
              <Crown className="w-12 h-12 text-amber-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-yellow-900 mb-2">God's Vision</h3>
              <p className="text-yellow-800 font-medium mb-2">Peace for All Nations</p>
              <p className="text-yellow-700 text-sm">Nations come to learn God's ways and beat swords into plowshares</p>
            </div>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4].map(num => (
                <div key={num} className="w-8 h-8 bg-amber-200 rounded-lg border border-amber-300 flex items-center justify-center">
                  <span className="text-xs font-bold text-amber-800">{num}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Hinge - Verse 5 */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-orange-100 to-yellow-100 border-2 border-orange-400 rounded-xl p-6 transform scale-110 shadow-lg">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold text-xl">5</span>
              </div>
              <h3 className="text-xl font-bold text-orange-900 mb-2">The Hinge</h3>
              <p className="text-orange-800 text-sm font-medium mb-2">"Come, walk in God's light"</p>
              <p className="text-orange-700 text-xs">The gentle invitation that connects vision to reality</p>
            </div>
            <p className="text-xs text-orange-600 mt-2">Pivot Point • Choice to Make</p>
          </div>

          {/* Warning Section (6-22) */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-stone-100 to-gray-100 border border-stone-300 rounded-xl p-6 mb-4 shadow-md">
              <Shield className="w-12 h-12 text-stone-600 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-stone-900 mb-2">What Gets in the Way</h3>
              <p className="text-stone-800 font-medium mb-2">Pride & False Gods</p>
              <p className="text-stone-700 text-sm">Warning about idols, wealth, and hiding from God's glory</p>
            </div>
            <div className="grid grid-cols-6 gap-1 justify-items-center">
              {[6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22].map(num => (
                <div key={num} className="w-6 h-6 bg-stone-200 rounded-md border border-stone-300 flex items-center justify-center">
                  <span className="text-xs font-bold text-stone-700">{num}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Interactive Grid */}
      <VerseOverview
        data={data}
        selectedVerse={selectedVerse}
        onVerseSelect={handleVerseSelect}
        analysisMode={analysisMode}
        onAnalysisModeChange={handleAnalysisModeChange}
      />

      {/* Understanding the Structure */}
      <div className="bg-white rounded-xl border border-amber-200 shadow-lg p-8">
        <h3 className="text-2xl font-bold text-amber-900 mb-6 text-center">Understanding the Chiastic Structure</h3>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* How It Works */}
          <div>
            <h4 className="text-lg font-semibold text-amber-800 mb-4 flex items-center gap-2">
              <Eye className="w-5 h-5" />
              How to Read the Pattern
            </h4>
            <div className="space-y-4 text-gray-700">
              <p className="text-sm leading-relaxed">
                <strong>Chiastic structure</strong> is like a mirror - the first part reflects the last part, 
                creating beautiful contrasts and connections.
              </p>
              <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
                <div className="text-center space-y-2 text-sm">
                  <div className="font-mono">A - Vision opening (vv 1-2)</div>
                  <div className="font-mono ml-4">B - Vision peace (vv 3-4)</div>
                  <div className="font-mono ml-8 text-orange-700 font-bold">C - HINGE (v 5)</div>
                  <div className="font-mono ml-4">B' - Warning conflict (vv 6-18)</div>
                  <div className="font-mono">A' - Warning closing (vv 19-22)</div>
                </div>
              </div>
            </div>
          </div>

          {/* What to Look For */}
          <div>
            <h4 className="text-lg font-semibold text-amber-800 mb-4">What to Look For</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-amber-400 rounded-full mt-2 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-gray-900">Anti-Pairs</div>
                  <div className="text-sm text-gray-600">Verses that contrast thematically across sections</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-gray-900">Repeated Motifs</div>
                  <div className="text-sm text-gray-600">Phrases or themes repeated for emphasis</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-gray-900">Movement Patterns</div>
                  <div className="text-sm text-gray-600">Upward (toward God) vs. downward (hiding from God)</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-gray-900">Transformation Themes</div>
                  <div className="text-sm text-gray-600">What changes when people follow God vs. themselves</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Usage Guide */}
      <div className="bg-blue-50 rounded-xl border border-blue-200 p-6">
        <h3 className="text-xl font-semibold text-blue-900 mb-4">How to Use This Interactive Study</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-medium text-blue-800 mb-2">1. Choose Your Mode</h4>
            <p className="text-blue-700 text-sm">Select Structure Focus, Life Application, or Compare Analysis based on your study goals.</p>
          </div>
          <div>
            <h4 className="font-medium text-blue-800 mb-2">2. Explore the Grid</h4>
            <p className="text-blue-700 text-sm">Hover over verses to see relationships light up. Colors show how verses connect structurally.</p>
          </div>
          <div>
            <h4 className="font-medium text-blue-800 mb-2">3. Dive Deeper</h4>
            <p className="text-blue-700 text-sm">Click any verse for detailed analysis tailored to your chosen study mode.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChiasticVisualizer;