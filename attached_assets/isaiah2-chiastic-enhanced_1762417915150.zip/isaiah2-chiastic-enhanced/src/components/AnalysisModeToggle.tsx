import React from 'react';
import { Eye, Lightbulb, ArrowRightLeft } from 'lucide-react';
import type { AnalysisMode } from '../types';

interface AnalysisModeToggleProps {
  analysisMode: AnalysisMode;
  setAnalysisMode: (mode: AnalysisMode) => void;
}

const AnalysisModeToggle: React.FC<AnalysisModeToggleProps> = ({
  analysisMode,
  setAnalysisMode,
}) => {
  const modes = [
    {
      id: 'structure' as AnalysisMode,
      label: 'Structure Focus',
      icon: Eye,
      description: 'How parts connect'
    },
    {
      id: 'application' as AnalysisMode,
      label: 'Life Application',
      icon: Lightbulb,
      description: 'What it means today'
    },
    {
      id: 'compare' as AnalysisMode,
      label: 'Compare Sections',
      icon: ArrowRightLeft,
      description: 'Vision vs Warning'
    }
  ];

  return (
    <div className="bg-white rounded-lg border border-amber-200 shadow-md p-1 flex">
      {modes.map((mode) => {
        const Icon = mode.icon;
        const isActive = analysisMode === mode.id;
        
        return (
          <button
            key={mode.id}
            onClick={() => setAnalysisMode(mode.id)}
            className={`px-4 py-3 rounded-md text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
              isActive
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-amber-700 hover:bg-amber-50'
            }`}
            title={`${mode.label} Analysis - ${mode.description}`}
          >
            <Icon className="w-4 h-4" />
            <div className="text-left">
              <div className="font-medium">{mode.label}</div>
              <div className={`text-xs ${isActive ? 'text-amber-100' : 'text-amber-500'}`}>
                {mode.description}
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default AnalysisModeToggle;