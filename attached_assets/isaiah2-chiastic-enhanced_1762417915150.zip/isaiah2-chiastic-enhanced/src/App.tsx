import React, { useState, useEffect } from 'react';
import { BookOpen } from 'lucide-react';
import type { Isaiah2EnhancedData } from './types';
import ChiasticVisualizer from './components/ChiasticVisualizer';
import LoadingSpinner from './components/LoadingSpinner';
import './App.css';

function App() {
  const [data, setData] = useState<Isaiah2EnhancedData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/data/isaiah2-8color-system.json')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then((data: Isaiah2EnhancedData) => {
        setData(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error loading 8-color system data:', error);
        setError(`Failed to load analysis data: ${error.message}`);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-lg border border-red-200 max-w-md">
          <BookOpen className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-900 mb-2">Error Loading Analysis</h2>
          <p className="text-red-700 text-sm mb-4">{error || 'Unable to load the Isaiah 2 analysis data.'}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      {/* Simplified Header */}
      <header className="bg-gradient-to-r from-amber-100 via-orange-100 to-yellow-100 border-b border-amber-200 shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-3">
              <BookOpen className="w-8 h-8 text-amber-700" />
              <h1 className="text-3xl lg:text-4xl font-bold text-amber-900">
                {data.title}
              </h1>
            </div>
            <p className="text-amber-700 text-lg font-medium mb-2">{data.subtitle}</p>
            <p className="text-amber-600 text-sm">{data.version}</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <ChiasticVisualizer data={data} />
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-amber-100 to-orange-100 border-t border-amber-200 py-6 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-amber-700 text-sm">
            Isaiah 2 Interactive Study • 8-Color Structural Analysis • {data.version}
          </p>
          <p className="text-amber-600 text-xs mt-1">
            Hover over verses to see structural relationships • Click for detailed analysis
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;