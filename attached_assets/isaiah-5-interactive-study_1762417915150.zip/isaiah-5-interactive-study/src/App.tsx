import React, { useState } from 'react';
import './App.css';

interface ViewingMode {
  id: string;
  title: string;
  description: string;
}

interface Verse {
  number: number;
  text: string;
  group: number;
  isHinge?: boolean;
}

// Verse data from Isaiah 5:1-5:30
const verses: Verse[] = [
  { number: 1, text: "Let me sing for my beloved my love song concerning his vineyard: My beloved had a vineyard on a very fertile hill.", group: 1 },
  { number: 2, text: "He dug it and cleared it of stones, and planted it with choice vines; he built a watchtower in the midst of it, and hewed out a wine vat in it; and he looked for it to yield grapes, but it yielded wild grapes.", group: 1 },
  { number: 3, text: "And now, O inhabitants of Jerusalem and men of Judah, judge between me and my vineyard.", group: 1 },
  { number: 4, text: "What more was there to do for my vineyard, that I have not done in it? When I looked for it to yield grapes, why did it yield wild grapes?", group: 1 },
  { number: 5, text: "And now I will tell you what I will do to my vineyard. I will remove its hedge, and it shall be devoured; I will break down its wall, and it shall be trampled down.", group: 1 },
  { number: 6, text: "I will make it a waste; it shall not be pruned or hoed, and briers and thorns shall grow up; I will also command the clouds that they rain no rain upon it.", group: 1 },
  { number: 7, text: "For the vineyard of the Lord of hosts is the house of Israel, and the men of Judah are his pleasant planting; and he looked for justice, but behold, bloodshed; for righteousness, but behold, an outcry!", group: 1, isHinge: true },
  { number: 8, text: "Woe to those who join house to house, who add field to field, until there is no more room, and you are made to dwell alone in the midst of the land.", group: 2 },
  { number: 9, text: "The Lord of hosts has sworn in my hearing: \"Surely many houses shall be desolate, large and beautiful houses, without inhabitant.", group: 2 },
  { number: 10, text: "For ten acres of vineyard shall yield but one bath, and a homer of seed shall yield but an ephah.", group: 2 },
  { number: 11, text: "Woe to those who rise early in the morning, that they may run after strong drink, who tarry late into the evening as wine inflames them!", group: 2 },
  { number: 12, text: "They have lyre and harp, tambourine and flute and wine at their feasts, but they do not regard the deeds of the Lord, or see the work of his hands.", group: 2 },
  { number: 13, text: "Therefore my people go into exile for lack of knowledge; their honored men go hungry, and their multitude is parched with thirst.", group: 2, isHinge: true },
  { number: 14, text: "Therefore Sheol has enlarged its appetite and opened its mouth beyond measure, and the nobility of Jerusalem and her multitude will go down, her revelers and he who exults in her.", group: 2 },
  { number: 15, text: "Man is humbled, and each one is brought low, and the eyes of the haughty are brought low.", group: 2 },
  { number: 16, text: "But the Lord of hosts is exalted in justice, and the Holy God shows himself holy in righteousness.", group: 6 },
  { number: 17, text: "Then shall the lambs graze as in their pasture, and nomads shall eat among the ruins of the rich.", group: 6 },
  { number: 18, text: "Woe to those who draw iniquity with cords of falsehood, who draw sin as with cart ropes,", group: 3 },
  { number: 19, text: "who say: \"Let him be quick, let him speed his work that we may see it; let the counsel of the Holy One of Israel draw near, and let it come, that we may know it!\"", group: 3 },
  { number: 20, text: "Woe to those who call evil good and good evil, who put darkness for light and light for darkness, who put bitter for sweet and sweet for bitter!", group: 3 },
  { number: 21, text: "Woe to those who are wise in their own eyes, and shrewd in their own sight!", group: 3 },
  { number: 22, text: "Woe to those who are heroes at drinking wine, and valiant men in mixing strong drink,", group: 3 },
  { number: 23, text: "who acquit the guilty for a bribe, and deprive the innocent of his right!", group: 3 },
  { number: 24, text: "Therefore, as the tongue of fire devours the stubble, and as dry grass sinks down in the flame, so their root will be as rottenness, and their blossom go up like dust; for they have rejected the law of the Lord of hosts, and have despised the word of the Holy One of Israel.", group: 4, isHinge: true },
  { number: 25, text: "Therefore the anger of the Lord was kindled against his people, and he stretched out his hand against them and struck them, and the mountains quaked; and their corpses were as refuse in the midst of the streets. For all this his anger has not turned away, and his hand is stretched out still.", group: 4 },
  { number: 26, text: "He will raise a signal for nations far away, and whistle for them from the ends of the earth; and behold, quickly, speedily they come!", group: 5 },
  { number: 27, text: "None is weary, none stumbles, none slumbers or sleeps, not a waistband is loose, not a sandal strap broken;", group: 5 },
  { number: 28, text: "their arrows are sharp, all their bows bent, their horses' hoofs seem like flint, and their wheels like the whirlwind.", group: 5 },
  { number: 29, text: "Their roaring is like a lion, like young lions they roar; they growl and seize their prey; they carry it off, and none can rescue.", group: 5 },
  { number: 30, text: "They will growl over it on that day, like the growling of the sea. And if one looks to the land, behold, darkness and distress; and the light is darkened by its clouds.", group: 5 }
];

const viewingModes: ViewingMode[] = [
  {
    id: 'connections',
    title: 'Seeing Connections',
    description: 'How the verses connect in the four-phase progression'
  },
  {
    id: 'life',
    title: 'How This Helps My Life',
    description: 'Personal spiritual insights about God\'s expectations'
  },
  {
    id: 'teaching',
    title: 'What This Teaches Us',
    description: 'Contrasts between divine care and human failure'
  }
];

function App() {
  const [activeViewingMode, setActiveViewingMode] = useState<string>('connections');
  const [selectedVerse, setSelectedVerse] = useState<Verse | null>(null);
  const [hoveredVerse, setHoveredVerse] = useState<number | null>(null);

  const getColorClass = (group: number, verse: number) => {
    const isHinge = verses.find(v => v.number === verse)?.isHinge;
    const baseColors = {
      1: 'bg-gradient-to-br from-teal-500 to-teal-600', // Vineyard Parable
      2: 'bg-gradient-to-br from-amber-500 to-amber-600', // First Woe Cycle
      3: 'bg-gradient-to-br from-red-600 to-red-700', // Second Woe Cycle
      4: 'bg-gradient-to-br from-blue-800 to-blue-900', // Therefore Verdict
      5: 'bg-gradient-to-br from-slate-600 to-slate-700', // Orchestration
      6: 'bg-gradient-to-br from-lime-600 to-lime-700' // Reversals & Doxological
    };
    
    let colorClass = baseColors[group as keyof typeof baseColors] || 'bg-gray-500';
    
    // Add special effects for hinge verses
    if (isHinge) {
      colorClass += ' ring-2 ring-yellow-400 ring-opacity-60';
    }
    
    return colorClass;
  };

  const getTooltipContent = (mode: string, verse: Verse) => {
    const verseConnections = {
      1: "The song begins—God speaks tenderly about His people as His vineyard, planted with care and expectation.",
      2: "All the preparation is complete—God has done everything needed for good fruit to grow.",
      7: "The interpretive center—God reveals that His people were supposed to produce justice and righteousness, not bloodshed and outcry.",
      13: "The first consequence—\"Therefore\" marks the turning point where words become actions.",
      16: "A beautiful interruption—God declares His own holiness and justice in the midst of judgment.",
      20: "The heart of the problem—moral confusion where right becomes wrong and wrong becomes right.",
      24: "The final verdict—God's word against those who reject His law and despise His word."
    };

    const verseLife = {
      1: "God sees us as His beloved. He has placed us in good soil with all we need to grow in His love.",
      2: "God has given you talents, opportunities, and His Spirit— He's prepared everything for good fruit in your life.",
      7: "Are you producing the justice and righteousness that God expects from His people?",
      13: "When we ignore God's word, we lose our way. Knowledge of God leads to life, not to ruin.",
      16: "Even in difficult times, God remains holy and just. He always acts according to His perfect nature.",
      20: "Beware of moral confusion in our culture. God calls us to stand for truth even when it's unpopular.",
      24: "God's judgment always begins with His people. We must take His word seriously and not reject it."
    };

    const verseTeaching = {
      1: "God's love is patient and personal. He sings over His people with tender affection.",
      2: "God has done everything for our success. Our responsibility is to bear fruit that honors Him.",
      7: "God expects justice and righteousness from His people, not corruption and violence.",
      13: "Ignoring God leads to exile from His presence and provision in our lives.",
      16: "God is always exalted in justice, even when His people face discipline.",
      20: "Moral relativism is not new—people have always tried to invert good and evil.",
      24: "God's word is sacred. Those who reject it face the consequences of their choices."
    };

    switch (mode) {
      case 'connections':
        return {
          title: `Isaiah 5:${verse.number} - ${getGroupTitle(verse.group)}`,
          content: verseConnections[verse.number as keyof typeof verseConnections] || 
                  "This verse continues the progression from expectation through judgment to God's ultimate plan for restoration."
        };
      case 'life':
        return {
          title: `What This Means for Your Life`,
          content: verseLife[verse.number as keyof typeof verseLife] || 
                  "God has placed you where you are with the expectation that you'll bear good fruit for His glory."
        };
      case 'teaching':
        return {
          title: `What God is Teaching Us`,
          content: verseTeaching[verse.number as keyof typeof verseTeaching] || 
                  "This verse shows us God's character and what He expects from His people in this world."
        };
      default:
        return { title: '', content: '' };
    }
  };

  const getGroupTitle = (group: number) => {
    const titles = {
      1: 'Vineyard Parable & Expectation',
      2: 'First Wave of Consequences',
      3: 'Moral Inversion & Corruption',
      4: 'Divine Verdict & Judgment',
      5: 'International Judgment',
      6: 'Reversal & Hope'
    };
    return titles[group as keyof typeof titles] || '';
  };

  const getGroupTransition = (group: number) => {
    const transitions = {
      1: 'God\'s love song - vineyard planted, tended, and expecting good fruit',
      2: 'Consequences begin - social sins lead to exile and hunger',
      3: 'Moral inversion - corruption spreads, right becomes wrong',
      4: 'Divine verdict - God\'s final word and cosmic judgment',
      5: 'International scope - nations mobilized against God\'s people',
      6: 'Reversal and hope - doxological pivot toward restoration'
    };
    return transitions[group as keyof typeof transitions] || 'Transition in the vineyard judgment progression';
  };

  const getDetailedReflection = (verse: Verse) => ({
    title: `Isaiah 5:${verse.number} - ${getGroupTitle(verse.group)}`,
    mainContent: `This verse shows us the progression from God's loving care to His righteous judgment.

**What This Means for Your Life:**
- God has placed you in a position of privilege and responsibility
- He expects you to bear good fruit that honors His name
- When we ignore God's expectations, natural consequences follow
- God always acts according to His holy character

**Questions for Reflection:**
- How has God prepared you for good fruit in your life?
- What is God looking for from you—justice, righteousness, integrity?
- Where might you be settling for \"wild grapes\" instead of the good fruit God expects?
- How does this passage challenge your understanding of God's patience and justice?

**How This Applies to Daily Life:**
God's people are called to be different—marked by justice, righteousness, and integrity. When we compromise these values, we damage not only ourselves but also our witness to the world. This passage reminds us that God is both patient and holy.

**What God is Teaching Us Here:**
God's people don't operate by the world's standards. We are called to produce spiritual fruit that brings honor to God's name. This means pursuing justice, practicing righteousness, and living with integrity in all aspects of our lives.`,
    connections: `This verse fits into God's larger plan:

- **From Chapter 4**: Builds on God's promise of cleansing and holiness
- **To Chapter 6**: Shows why God's people needed to experience judgment before renewal
- **Forward Impact**: Helps us understand God's character and what He expects from His people today`
  });

  const getVerseGroup = (verseNumber: number) => {
    for (const verse of verses) {
      if (verse.number === verseNumber) return verse.group;
    }
    return 1;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Isaiah Chapter 5 Interactive Study</h1>
          <p className="text-lg text-gray-600">30 Verses of Divine Expectation and Human Failure</p>
        </div>

        {/* Viewing Mode Selector */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-2 shadow-md">
            {viewingModes.map((mode) => (
              <button
                key={mode.id}
                onClick={() => setActiveViewingMode(mode.id)}
                className={`
                  px-4 py-2 mx-1 rounded-md text-sm font-medium transition-colors
                  ${activeViewingMode === mode.id 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }
                `}
              >
                {mode.title}
              </button>
            ))}
          </div>
        </div>

        {/* Key Transformation Points */}
        <div className="bg-white rounded-lg p-4 shadow-md mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Key transformation points</h3>
          <div className="flex items-start gap-3">
            <div className="w-3 h-3 bg-yellow-400 rounded-full mt-1 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">Yellow dots mark moments where everything changes—from vineyard expectation to divine judgment, from protection to removal, from verdant to desolation.</p>
          </div>
        </div>

        {/* Verses Grid */}
        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3 mb-8">
          {verses.map((verse) => (
            <div
              key={verse.number}
              className={`
                relative aspect-square rounded-lg shadow-md cursor-pointer transform transition-all duration-300
                hover:scale-105 hover:z-10
                ${getColorClass(verse.group, verse.number)}
                ${hoveredVerse === verse.number ? 'ring-2 ring-white ring-opacity-80' : ''}
              `}
              onClick={() => setSelectedVerse(verse)}
              onMouseEnter={() => setHoveredVerse(verse.number)}
              onMouseLeave={() => setHoveredVerse(null)}
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-xs font-bold">5:{verse.number}</div>
                </div>
              </div>
              
              {/* Hover Tooltip */}
              {hoveredVerse === verse.number && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-20">
                  <div className="bg-white rounded-lg shadow-xl p-3 w-64 border">
                    <div className="text-xs font-semibold text-gray-500 mb-1">
                      {getTooltipContent(activeViewingMode, verse).title}
                    </div>
                    <div className="text-xs text-gray-700 mb-2">
                      {verse.text}
                    </div>
                    <div className="text-xs text-gray-600">
                      {getTooltipContent(activeViewingMode, verse).content}
                    </div>
                    {/* Tooltip arrow */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 -translate-y-1 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white"></div>
                  </div>
                </div>
              )}
              
              {/* Hinge indicator */}
              {verse.isHinge && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full border-2 border-white"></div>
              )}
            </div>
          ))}
        </div>

        {/* Color Legend */}
        <div className="bg-white rounded-lg p-6 shadow-md mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Understanding the Progression</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }, (_, i) => i + 1).map((group) => (
              <div key={group} className="flex items-start space-x-3">
                <div className={`w-4 h-4 rounded mt-1 flex-shrink-0 ${getColorClass(group, 1).replace('ring-2', '').replace('ring-opacity-60', '')}`}></div>
                <div>
                  <div className="font-medium text-gray-900">{getGroupTitle(group)}</div>
                  <div className="text-sm text-gray-600">{getGroupTransition(group)}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <span className="text-sm font-medium text-gray-700">Key transition points (hinges)</span>
            </div>
            <p className="text-sm text-gray-600">
              Yellow dots mark important turning points where the chapter shifts from one phase to another.
            </p>
          </div>
        </div>

        {/* Detailed Reflection Modal */}
        {selectedVerse && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">
                    Isaiah 5:{selectedVerse.number} - {getGroupTitle(selectedVerse.group)}
                  </h2>
                  <button
                    onClick={() => setSelectedVerse(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>
                
                <div className="prose max-w-none">
                  <div>
                    <div className="text-sm text-gray-500 mb-4 italic">
                      Isaiah 5:{selectedVerse.number} (ESV)
                    </div>
                    
                    <div className="text-lg text-gray-800 mb-4">
                      {selectedVerse.text}
                    </div>
                    
                    <div className="whitespace-pre-line text-gray-700">
                      {getDetailedReflection(selectedVerse).mainContent}
                    </div>
                    
                    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Connections Throughout Scripture</h4>
                      <p className="text-sm text-gray-700">
                        {getDetailedReflection(selectedVerse).connections}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;